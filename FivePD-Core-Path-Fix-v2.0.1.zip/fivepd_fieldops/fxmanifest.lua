fx_version 'cerulean'
game 'gta5'
author 'FivePD Korean'
description 'Field lifecycle: station entry, injury recovery and physical EMS'
version '1.0.0'
dependency 'fivepd'
ui_page 'web/index.html'
client_scripts {'client/lifecycle.lua', 'client/ems.lua'}
server_script 'server/deployment.lua'
files {'web/**/*', 'assets/mission-row.png'}
