import{V as o}from"./chunk-6DGEKYP3.js";var t=new o("Callsign format items");export{t as a};
