import{X as o,_ as n,ea as r,i as e}from"./chunk-6DGEKYP3.js";function s(){n(s);let c=o(r),t=new e(1);return c.onDestroy(()=>{t.next(),t.complete()}),t}export{s as a};
