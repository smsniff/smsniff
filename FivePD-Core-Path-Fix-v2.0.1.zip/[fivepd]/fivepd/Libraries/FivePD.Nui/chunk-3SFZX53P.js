import{a as N}from"./chunk-FMBTOKUT.js";import{$ as s,Ba as c,Gb as k,Ha as u,Ia as p,Ka as m,Pa as h,Qa as o,Ra as y,Ua as x,Va as w,Wa as n,Yb as z,aa as a,eb as C,fb as g,ha as l,pa as d,ta as b,ub as v,va as f,vb as _}from"./chunk-6DGEKYP3.js";function j(t,I){if(t&1){let e=x();o(0,"button",1),w("click",function(){s(e);let r=n();return a(r.internalOnClick())}),o(1,"span",2),C(2),v(3,"translate"),y()()}if(t&2){let e=n();h("ngClass",e.className)("disabled",e.disabled),u("type",e.type),d(2),g(_(3,4,e.label))}}var O={primary:`text-white flex flex-col justify-center items-center
              border border-transparent
              before:absolute before:inset-0 before:w-full before:h-full before:rounded-md
              before:bg-primary
              disabled:cursor-not-allowed disabled:opacity-50`,secondary:`text-white flex flex-col justify-center items-center
              border border-zinc-600 rounded-md
              before:absolute before:inset-0 before:w-full before:h-full before:rounded-md
              before:bg-transparent
              disabled:cursor-not-allowed disabled:opacity-50`,tertiary:`text-white flex flex-col justify-center items-center
              border border-transparent
              before:absolute before:inset-0 before:w-full before:h-full before:rounded-md
              before:bg-zinc-800
              disabled:cursor-not-allowed disabled:opacity-50`,"tertiary-bg":`text-white flex flex-col justify-center items-center
              border border-transparent
              before:absolute before:inset-0 before:w-full before:h-full before:rounded-md
              before:bg-zinc-700
              disabled:cursor-not-allowed disabled:opacity-50`,danger:`text-white flex flex-col justify-center items-center
              border border-transparent
              before:absolute before:inset-0 before:w-full before:h-full before:rounded-md
              before:bg-red-600
              disabled:cursor-not-allowed disabled:opacity-50`},B={primary:"enabled:hover:before:opacity-75",secondary:"enabled:hover:border-white",tertiary:"enabled:hover:before:bg-zinc-700","tertiary-bg":"enabled:hover:before:bg-zinc-600",danger:"enabled:hover:before:opacity-75"},V={base:"text-base",sm:"text-sm font-medium"},R=(()=>{class t{constructor(e){this._router=e,this.label="",this.variant="primary",this.size="base",this.type="button",this.show=!0,this.disabled=!1,this.fullWidth=!1,this.onClick=new c,this.className=[]}ngOnInit(){this.setClassName()}ngOnChanges(){this.setClassName()}setClassName(){this.className=[O[this.variant],B[this.variant],V[this.size],this.fullWidth?"w-full":"w-max","h-[40px] px-4 relative"]}internalOnClick(){this.link?this._router.navigate([...this.link]):this.onClick.emit()}static{this.\u0275fac=function(i){return new(i||t)(b(z))}}static{this.\u0275cmp=f({type:t,selectors:[["app-button"]],inputs:{label:"label",variant:"variant",size:"size",type:"type",show:"show",disabled:"disabled",fullWidth:"fullWidth",link:"link"},outputs:{onClick:"onClick"},features:[l],decls:1,vars:1,consts:[[3,"ngClass","disabled"],[3,"click","ngClass","disabled"],[1,"z-10"]],template:function(i,r){i&1&&p(0,j,4,6,"button",0),i&2&&m(r.show?0:-1)},dependencies:[N,k],encapsulation:2})}}return t})();export{R as a};
