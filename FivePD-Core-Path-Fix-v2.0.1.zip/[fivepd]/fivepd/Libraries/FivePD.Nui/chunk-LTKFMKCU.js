import{a as t,b as r}from"./chunk-6DGEKYP3.js";function l(i,e){return r(t({},i),{Filters:t(t({},i.Filters),e)})}export{l as a};
