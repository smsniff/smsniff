local resource = GetCurrentResourceName()
local essential = {
    'stream/mrs_interior.ytyp', 'stream/mrs_garage.ytyp', 'stream/mrs_objects.ytyp',
    'stream/mrs_props.ytyp', 'stream/downtown_01_metadata_002_strm.ytyp',
    'stream/hei_dlc_heist_police.ytyp', 'stream/mrs_interior_placement.ymap',
    'stream/mrs_mlo_placement.ymap', 'stream/mrs_garage_collision.ybn'
}
local function report()
    local missing = {}
    for _, file in ipairs(essential) do
        if not LoadResourceFile(resource, file) then missing[#missing + 1] = file end
    end
    print(('[Mission Row] path: %s'):format(GetResourcePath(resource) or 'missing'))
    print(('[Mission Row] required map files: %s'):format(#missing == 0 and 'present' or table.concat(missing, ', ')))
    print(('[Mission Row] field layout: %s; core update: %s'):format(
        GetConvar('fivepd_missionrow_layout', 'default'),
        GetResourceMetadata('fivepd', 'operations_update', 0) or 'unknown'))
end
RegisterCommand('missionrow_status', function(source) if source == 0 then report() end end, true)
AddEventHandler('onResourceStart', function(name) if name == resource then report() end end)
