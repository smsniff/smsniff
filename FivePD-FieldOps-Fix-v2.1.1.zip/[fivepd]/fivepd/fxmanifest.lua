fx_version 'cerulean'
game 'gta5'

author 'FivePD'
version '2.0.0'

ui_page 'Libraries/FivePD.Nui/index.html'
client_script 'Libraries/FivePD.Client/FivePD.Client.net.dll'
server_script 'Libraries/FivePD.Server/FivePD.Server.net.dll'
server_script 'Deployment/status.lua'
operations_update '2.1.1'

files {
    'Libraries/FivePD.Client/**/*',
    'Libraries/FivePD.Nui/**/*',
    'Localizations/**/*',
	'Config/**/*'
}
chat_theme 'fivepd-shared-fonts' {
    styleSheet = 'Libraries/FivePD.Nui/assets/fieldops/shared-chat.css'
}
