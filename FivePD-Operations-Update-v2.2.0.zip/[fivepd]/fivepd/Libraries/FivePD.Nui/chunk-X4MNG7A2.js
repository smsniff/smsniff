function t(r){return typeof r=="string"&&(r=parseInt(r)),r}export{t as a};
