local status
local function safe(value) return tostring(value or '?'):gsub('[~\r\n]', '') end
RegisterNetEvent('fivepd_weaponwheel:status', function(data)
    if type(data) == 'table' then status = data end
end)
CreateThread(function()
    -- Request once after the local client resource starts; periodic server
    -- snapshots also restore the footer after a resource restart.
    TriggerServerEvent('fivepd_weaponwheel:status:request')
    while true do
        local settings = Config.StatusHud
        if settings.Enabled and status and not IsPauseMenuActive() and not IsScreenFadedOut() then
            local version = 'v'..safe(status.version)
            if settings.ShowResourceState or status.state ~= 'started' then
                local states = {started='STARTED',starting='STARTING',stopped='STOPPED',stopping='STOPPING',missing='MISSING'}
                version = version..' / '..(states[status.state] or 'UNKNOWN')
            end
            local text = ('~b~FivePD~s~ %s - %d/%d - %s'):format(version,
                math.max(0,tonumber(status.players) or 0),math.max(1,tonumber(status.maximum) or 1),safe(status.time))
            SetTextFont(settings.Font)
            SetTextProportional(true)
            SetTextScale(0.0, settings.Scale)
            SetTextColour(255,255,255,245)
            SetTextCentre(true)
            SetTextWrap(0.0,1.0)
            SetTextDropShadow(1,0,0,0,220)
            SetTextOutline()
            BeginTextCommandDisplayText('STRING')
            AddTextComponentSubstringPlayerName(text)
            EndTextCommandDisplayText(settings.X,settings.Y)
            Wait(0)
        else Wait(200) end
    end
end)
