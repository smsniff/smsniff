// All coordinates are in the SVG's 640 x 640 space.
export const C = 320;
export const CENTRE_RADIUS = 83;
export const OUTER_RADIUS = 285;
export const SLOT_ANGLES = {1:180, 2:270, 3:90, 4:0};
export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
export function wheelSize(scale) {
  return 64*clamp(Number.isFinite(scale)?scale:.94,.45,1.4);
}
export function point(radius, degrees) {
  const a = degrees * Math.PI / 180;
  return [C + radius * Math.cos(a), C + radius * Math.sin(a)];
}
export function arc(radius, start, end) {
  const a = point(radius, start), b = point(radius, end);
  return `M ${a[0]} ${a[1]} A ${radius} ${radius} 0 ${end-start > 180 ? 1:0} 1 ${b[0]} ${b[1]}`;
}
export function sector(slot) {
  const a = SLOT_ANGLES[slot] - 43, b = SLOT_ANGLES[slot] + 43;
  const start = point(157, a), end = point(157, b), outerStart = point(285, a), outerEnd = point(285,b);
  return `M${start} L${outerStart} A285 285 0 0 1 ${outerEnd} L${end} A157 157 0 0 0 ${start} Z`;
}
export function slotAt(x, y) {
  const dx=x-C, dy=y-C;
  if (Math.hypot(dx,dy) < CENTRE_RADIUS + 12) return 5;
  if (Math.abs(dx) >= Math.abs(dy)) return dx < 0 ? 1:4;
  return dy < 0 ? 2:3;
}
export function normalizeSlots(items = []) {
  const slots = {1:[],2:[],3:[],4:[],5:[]};
  for (const item of items) {
    if (slots[item.slot] && Number.isFinite(item.hash)) slots[item.slot].push(item);
  }
  return slots;
}
export function cycleIndex(index, direction, length) {
  return length ? ((index + direction) % length + length) % length:0;
}
export function ammo(item) {
  return item?.hasAmmo ? `${Math.max(0,item.clip || 0)} ${Math.max(0,item.total || 0)}` : '';
}
