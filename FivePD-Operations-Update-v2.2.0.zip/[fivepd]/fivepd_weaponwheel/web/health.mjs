// This small module still reports errors if a later module import cannot load.
if(typeof GetParentResourceName==='function'){
  const sent=new Set();
  const report=message=>{
    const text=String(message||'Unknown frontend error').slice(0,600);
    if(sent.has(text)||sent.size>=3)return;sent.add(text);
    void fetch(`https://${GetParentResourceName()}/frontend-error`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text})}).catch(()=>{});
  };
  window.addEventListener('error',event=>report(event.message||event.target?.src),true);
  window.addEventListener('unhandledrejection',event=>report(event.reason?.message||event.reason));
}
