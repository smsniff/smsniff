import {C, SLOT_ANGLES, arc, sector, slotAt, normalizeSlots, cycleIndex, wheelSize} from './model.mjs';
import {icon, componentIcon} from './icons.mjs';
import {playEquip} from './audio.mjs';
import {weaponImages} from './catalog.mjs';

const $=id=>document.getElementById(id);
const overlay=$('overlay'), wheel=$('wheel');
const native=typeof window.GetParentResourceName==='function';
const resource=native?window.GetParentResourceName():null;
let opened=false, session=0, selected=5, slots=normalizeSlots(), indexes={}, pendingClose=false;
let inputMode='browser';
let pointer={x:C,y:C};
function callback(name,data={}) {
  if(!native) return Promise.resolve({ok:true});
  return fetch(`https://${resource}/${name}`,{method:'POST',headers:{'Content-Type':'application/json; charset=UTF-8'},body:JSON.stringify(data)})
    .then(r=>{if(!r.ok)throw new Error(`NUI ${name}: ${r.status}`);return r.json();});
}
const current=slot=>(slots[slot]||[])[indexes[slot]||0];
const NS='http://www.w3.org/2000/svg';
const slotNodes=new Map();
const componentOrder=['light','suppressor','magazine','scope','grip','muzzle','barrel','finish'];
function asset(item) {
  const path=item?.image||weaponImages[item?.hash];
  return typeof path==='string'&&/^images\/[a-zA-Z0-9_./-]+\.(png|svg|webp)$/.test(path)&&!path.includes('..')?path:null;
}
function artwork(item,x,y,width,height) {
  const path=asset(item);
  return path?`<image class="weapon-icon weapon-image" href="${path}" x="${x-width/2}" y="${y-height/2}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet"/>`:icon(item?.icon||'fist',x,y,width,height);
}
// Keep the sector nodes alive between inventory ticks. Replacing them on each
// hover used to reset CSS animation and image loading.
for(const slot of [1,2,3,4]) {
  const g=document.createElementNS(NS,'g');g.classList.add('wheel-sector');g.dataset.slot=slot;
  g.innerHTML=`<path class="sector" d="${sector(slot)}"/><path class="selection-fill" d="${sector(slot)}"/><path class="inner-ring" d="${arc(157,SLOT_ANGLES[slot]-42,SLOT_ANGLES[slot]+42)}"/><path class="selection-rim" d="${arc(285,SLOT_ANGLES[slot]-43,SLOT_ANGLES[slot]+43)}"/><g class="slot-content"></g>`;
  $('items').append(g);slotNodes.set(slot,{g,content:g.querySelector('.slot-content'),signature:''});
}
$('centre').innerHTML=`<circle class="centre-base" cx="320" cy="320" r="82"/>${artwork({hash:2725352035,icon:'fist'},320,320,64,64)}<text class="slot-number" x="320" y="383" text-anchor="middle">5</text>`;
function render() {
  for(const slot of [1,2,3,4]) {
    const item=current(slot),node=slotNodes.get(slot);
    node.g.classList.toggle('selected',selected===slot&&!!item);
    node.g.classList.toggle('empty',!item);
    if(!item){if(node.signature){node.content.innerHTML='';node.signature='';}continue;}
    const p={1:[100,320],2:[320,102],3:[320,548],4:[548,320]}[slot];
    const width=slot===2||slot===3?190:88;
    const kinds=componentOrder.filter(kind=>item.components?.[kind]!=null&&(['light','suppressor'].includes(kind)||item.components[kind]));
    const signature=JSON.stringify([item.hash,asset(item),item.icon,item.hasAmmo,kinds,slots[slot].length]);
    if(node.signature!==signature) {
    let markup=`<g class="slot-item">${artwork(item,p[0],p[1],width,slot===2||slot===3?94:92)}`;
    if(item.hasAmmo)markup+=`<text class="ammo" x="${p[0]}" y="${slot===2?57:p[1]+57}" text-anchor="middle"><tspan class="clip"></tspan><tspan class="reserve" dx="4"></tspan></text>`;
    const label={1:[121,156],2:[485,133],3:[430,502],4:[521,165]}[slot];
    markup+=`<text class="slot-number" x="${label[0]}" y="${label[1]}">${slot}</text>`;
    for(const [n,kind] of kinds.entries()) {
      const column=slot===1?(n===0?0:.5+(n-1)%2):(n===0?.5:(n-1)%2), row=n===0?0:1+Math.floor((n-1)/2);
      const base=slot===2?[397,126]:slot===1?[89,221]:slot===3?[400,488]:[515,218];
      markup+=`<g class="component" data-component="${kind}" transform="translate(${base[0]+column*28},${base[1]+row*28})"><title></title>${componentIcon(kind)}<path class="not-installed" d="M5 4 23 23"/><text class="ammo-type" x="14" y="33" text-anchor="middle"></text></g>`;
    }
    if(slots[slot].length>1)markup+=`<g class="multi" transform="translate(${p[0]+48},${p[1]+46})"><path d="M0 10V-10m-3 3 3-3 3 3M9-10v20m-3-3 3 3 3-3"/></g>`;
    node.content.innerHTML=markup+'</g>';node.signature=signature;
    }
    const clip=node.content.querySelector('.clip'),reserve=node.content.querySelector('.reserve');
    if(clip)clip.textContent=Math.max(0,item.clip||0);
    if(reserve)reserve.textContent=Math.max(0,item.total||0);
    for(const badge of node.content.querySelectorAll('[data-component]')) {
      const kind=badge.dataset.component,installed=!!item.components[kind],detail=item.componentDetails?.[kind];
      badge.classList.toggle('off',!installed);badge.classList.toggle('equipped',installed);
      badge.dataset.installed=String(installed);badge.dataset.variant=detail?.variant||kind;
      badge.querySelector('title').textContent=detail?.label||(installed?'장착됨':'미장착');
      badge.querySelector('.ammo-type').textContent=installed?({armor_piercing:'AP',fmj:'FMJ',incendiary:'INC',tracer:'TR',hollowpoint:'HP',explosive:'EXP'}[detail?.variant]||''):'';
    }
  }
  $('centre').classList.toggle('selected',selected===5);
  $('centre').querySelector('.centre-base').classList.toggle('selected',selected===5);
  $('weapon-name').textContent=current(selected)?.label||'맨손';
  $('pointer').setAttribute('transform',`translate(${pointer.x},${pointer.y})`);
}
function choose(slot) {
  if(!opened||!current(slot))return;
  if(slot!==selected){selected=slot;render();}
}
function movePointer(clientX,clientY) {
  const bounds=wheel.getBoundingClientRect();
  let x=(clientX-bounds.left)/bounds.width*640,y=(clientY-bounds.top)/bounds.height*640;
  const d=Math.hypot(x-C,y-C);
  if(d>302){x=C+(x-C)/d*302;y=C+(y-C)/d*302;}
  pointer={x,y};choose(slotAt(x,y));
  $('pointer').setAttribute('transform',`translate(${x},${y})`);
}
function cycle(direction) {
  const length=slots[selected]?.length||0;
  if(length>1&&direction!==0) {
    indexes[selected]=cycleIndex(indexes[selected]||0,direction>0?1:-1,length);render();
  }
}
function updateInventory(message,initial=false) {
  const old={};for(const slot of [1,2,3,4,5])old[slot]=current(slot)?.hash;
  slots=normalizeSlots(message.items);
  for(const slot of [1,2,3,4,5]) {
    const desired=initial?message.equipped:old[slot];
    const index=slots[slot].findIndex(w=>w.hash===desired);
    indexes[slot]=index>=0?index:0;
  }
  if(initial) {
    selected=Number(Object.keys(slots).find(slot=>slots[slot].some(w=>w.hash===message.equipped)))||5;
  }
  if(!current(selected))selected=5;
  render();
}
async function close(commit) {
  if(!opened||pendingClose)return;
  pendingClose=true;
  const closingSession=session;
  const hash=current(selected)?.hash;
  try {
    await callback('close',{session:closingSession,commit:!!commit,hash});
    if(session===closingSession){opened=false;overlay.hidden=true;}
  } catch(error) {
    // Lua's release watchdog hides the overlay if this callback cannot complete.
    console.error('Weapon wheel close failed',error);
  } finally {if(session===closingSession)pendingClose=false;}
}
window.addEventListener('message',({data})=>{
  if(!data||data.resource!=='fivepd_weaponwheel')return;
  if(data.action==='open') {
    session=data.session;opened=true;pendingClose=false;indexes={};
    inputMode=data.inputMode==='game'?'game':'browser';
    $('pointer').style.display=inputMode==='game'?'none':'';
    pointer={x:C,y:C};overlay.hidden=false;
    $('help').hidden=data.help===false;
    $('weapon-name').hidden=data.weaponName===false;
    $('wheel-container').style.width=`min(${wheelSize(data.scale)}vh,90vw)`;
    $('wheel-container').style.height=$('wheel-container').style.width;
    updateInventory(data,true);
  } else if(data.session===session) {
    if(data.action==='inventory'&&opened)updateInventory(data);
    if(data.action==='release')void close(true);
    if(data.action==='hide'){opened=false;overlay.hidden=true;}
    if(data.action==='equipped')playEquip(data.volume,data.sound);
    if(data.action==='input'&&opened&&inputMode==='game') {
      if(Number.isFinite(data.x)&&Number.isFinite(data.y))movePointer(data.x*innerWidth,data.y*innerHeight);
      if(Number.isInteger(data.slot))choose(data.slot);
      if(Number.isFinite(data.cycle))cycle(data.cycle);
    }
  }
});
window.addEventListener('mousemove',event=>{
  if(!opened||inputMode==='game')return;
  movePointer(event.clientX,event.clientY);
});
window.addEventListener('wheel',event=>{
  if(!opened||inputMode==='game')return;
  event.preventDefault();
  cycle(event.deltaY);
},{passive:false});
window.addEventListener('keydown',event=>{
  if(!opened||inputMode==='game')return;
  if(event.code==='Tab'||/^[1-5]$/.test(event.key))event.preventDefault();
  if(event.code==='Escape'){event.preventDefault();void close(false);}
  if(/^[1-5]$/.test(event.key))choose(Number(event.key));
});
window.addEventListener('keyup',event=>{
  if(opened&&inputMode!=='game'&&event.code==='Tab'){event.preventDefault();void close(true);}
});
window.addEventListener('blur',()=>{if(opened&&inputMode!=='game')void close(false);});
// Retry readiness after a resource / NUI reload. No frontend dependency or CDN.
if(native) {
  const instance=`${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const timer=setInterval(()=>callback('ready',{instance}).then(()=>clearInterval(timer)).catch(()=>{}),1000);
  void callback('ready',{instance}).then(()=>clearInterval(timer)).catch(()=>{});
}
// Explicit offline preview, never enabled in the FiveM NUI.
if(!native&&new URLSearchParams(location.search).get('preview')==='1') {
  window.postMessage({resource:'fivepd_weaponwheel',action:'open',session:1,equipped:2725352035,items:[
    {hash:324215364,slot:1,icon:'microsmg',label:'마이크로 SMG',hasAmmo:true,clip:16,total:60,components:{light:true,suppressor:false}},
    {hash:453432689,slot:1,icon:'pistol',label:'권총',hasAmmo:true,clip:12,total:72,components:{light:true,suppressor:true}},
    {hash:3220176749,slot:2,icon:'rifle',label:'돌격소총',hasAmmo:true,clip:60,total:149,components:{light:true,suppressor:false,magazine:true}},
    {hash:736523883,slot:3,icon:'smg',label:'기관단총',hasAmmo:true,clip:30,total:60,components:{light:true,suppressor:true}},
    {hash:2578778090,slot:4,icon:'knife',label:'칼',hasAmmo:false},
    {hash:2725352035,slot:5,icon:'fist',label:'맨손',hasAmmo:false},
  ]},'*');
}
