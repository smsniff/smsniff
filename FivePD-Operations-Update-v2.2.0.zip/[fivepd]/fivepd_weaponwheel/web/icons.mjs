// Original monochrome vector artwork; no extracted Rockstar / third-party textures.
const tone='fill="#939ba6" stroke="#111720" stroke-width="2.8" stroke-linejoin="round"';
const detail='fill="none" stroke="#c5cbd2" stroke-width="1.4" opacity=".7"';
const art={
  pistol:`<path ${tone} d="M18 26h98l8 6-5 19H68L53 87H30l13-38H18z"/><path ${tone} d="M56 48h26l-3 19H56l5-7h10l2-10"/><path ${detail} d="M25 32h83M31 38h72M89 29v14m7-14v14m7-14v14M37 76h14M40 68h14"/><path fill="#404a57" d="M21 49h24l-7 12H26z"/>`,
  microsmg:`<path ${tone} d="M8 32h115v22H77l-5 11h-9l-3 30H41l2-42H19L8 47z"/><path ${tone} d="M75 50h17l-4 19H69l2-8h9l3-9"/><path ${tone} d="M96 24h21v8H95zM24 23h20v10H24zM118 36h17v12h-17z"/><path ${detail} d="M16 38h102M17 44h102M48 60h9m-10 7h9m-10 7h9m-10 7h9M94 35v15m6-15v15m6-15v15"/>`,
  smg:`<path ${tone} d="M4 34h22l10 9h29l5-9h70v19H91l-9 15H67L52 88H39l11-34H29L7 64zM139 39h28v10h-28z"/><path ${tone} d="M84 52h16l4 31-14 6-9-26zM119 24h9v11h-9zM55 27h20v7H55z"/><path ${detail} d="M10 40h14l8 9H14M69 39h62M101 42h34m-26-3v12m7-12v12m7-12v12m7-12v12M87 56l9 25M44 77h10"/>`,
  rifle:`<path ${tone} d="M3 34h28l8 8 16-9h62l5-8h25l3 8h28v11h-67l-6 15H83l-8 21H62l6-31H40L5 62z"/><path ${tone} d="M94 48h13l10 28-12 7-17-28zM66 25h44v8H66zM132 20h8v14h-8zM162 27h4v16h-4z"/><path ${detail} d="M43 39h66m9-1h36M9 42h20L9 54m107-17v9m7-9v9m7-9v9m7-9v9m7-9v9m-48 7 12 23"/>`,
  shotgun:`<path ${tone} d="M4 34h164v12H91L79 56H49L9 72 4 60l24-21zM73 45h21l-8 30H71l6-21"/><path ${tone} d="M106 42h43v14h-43zM150 30h7v13h-7z"/><path ${detail} d="M17 38h142M110 45v8m7-8v8m7-8v8m7-8v8m7-8v8m7-8v8M13 58l26-10"/>`,
  sniper:`<path ${tone} d="M3 40h171v10H98l-7 14H57L7 77 3 63l27-17zM70 50h19l-8 29H67l7-23"/><path ${tone} d="M68 25h41v13H68zM61 22h13v20H61zM106 22h13v20h-13zM137 50l-7 34m13-34 10 34"/><path ${detail} d="M30 44h133M79 27h20m34 17h27"/>`,
  knife:`<path ${tone} d="M7 44h55l9-8 8 5h60l-14 11-46 6-8-5-9 7H7z"/><path ${detail} d="M80 46h45M16 48h36m-30-3v8m8-8v8m8-8v8m8-8v8"/>`,
  baton:`<path ${tone} d="M6 43h125l6 5-6 8H6zM40 51h11v36H40z"/><path ${detail} d="M14 46h111M42 58v22"/>`,
  taser:`<path ${tone} d="M16 27h103l9 15-13 18H69L54 90H31l11-38H16z"/><path fill="#ac9a60" stroke="#151c24" stroke-width="2" d="M20 31h95v17H60l-8 14H43l6-20H20z"/><path ${detail} d="M75 35h28m-26 6h22M38 76h13"/>`,
  heavy:`<path ${tone} d="M6 31h161v26H89L73 76H51l6-21H6zM113 57h14v18h-14z"/><path ${detail} d="M15 35h140M17 44h130m-90-9v17m8-17v17m8-17v17"/>`,
  grenade:`<path ${tone} d="M55 31l3-14h24l4 14 17 15 5 30-20 17H51L34 75l3-30zM65 15V6h35v10H80"/><path ${detail} d="M46 42h46M43 53h55M43 64h55M48 76h45M58 38v43m14-43v48m13-48v43"/>`,
  tool:`<path ${tone} d="M10 42h110v15H10zM72 25h20l18 16-16 15-7-14H72zM63 56h18v36H63z"/><path ${detail} d="M17 46h56m-6 17v23"/>`,
  fist:`<path ${tone} d="M30 41Q21 48 25 61l5 17q4 17 25 18l23-3q10-3 9-14l8-4q9-4 5-14l-4-7q7-8-1-15l-9-4q0-10-13-13l-13-3q-13-1-23 11z"/><path ${tone} d="m75 35 16 3q11 2 11 11 0 9-11 10l-16-5zM77 57l16-1q10 2 10 10-1 8-11 10l-15-3zM72 75l18-1q10 1 8 9-1 8-12 9H72z"/><path ${tone} d="M29 42q7-11 16-13l12 5 16 18q5 10-4 14L53 53l-6 14q-5 9-13 3l-8-13z"/><path ${tone} d="m31 74 15 3 9-5 14 5 7 13-17 5-15-3q-12-4-13-18z"/><path ${detail} d="m31 45 11-10 9 3m5 3 12 14M81 43l12 2M83 64h11M79 82h11M39 83l8 3 10-5"/>`,
};
export function icon(name,x,y,width,height=width*.65) {
  const v=name==='fist'?'0 0 130 110':['rifle','shotgun','sniper','heavy','smg'].includes(name)?'0 0 180 105':'0 0 145 110';
  return `<svg class="weapon-icon" x="${x-width/2}" y="${y-height/2}" width="${width}" height="${height}" viewBox="${v}" overflow="visible">${art[name]||art.pistol}</svg>`;
}
export function componentIcon(kind) {
  const shapes={
    light:'<path d="M9 17c0-3-3-3.8-3-7a6 6 0 0 1 12 0c0 3.2-3 4-3 7v1H9zM9.5 20h5m-4 1.5h3"/><path class="badge-detail" d="M9 8q2-2.5 4.5-1.2"/>',
    suppressor:'<path d="m7.5 5.5 10 10q1.5 1.5-.2 3t-3-.1l-10-10q-1.2-1.5.2-3t3 .1z"/><path class="badge-detail" d="m6 8 9.8 9.8M8.2 10l2-2M12 14l2-2"/>',
    magazine:'<path d="M5 18v-7l1.5-5L8 11v7zM10.5 18V9L12 4l1.5 5v9zM16 18v-7l1.5-5L19 11v7zM5 16h3m2.5 0h3m2.5 0h3"/>',
    scope:'<path d="M4 9h4V7h9v2h3v7h-3v2H8v-2H4z"/><circle cx="12" cy="12.5" r="5"/><path class="badge-detail" d="M12 8v9m-4-4.5h8"/>',
    grip:'<path d="M6 5h13v5h-4l-4 12H5l5-12H6z"/><path class="badge-detail" d="m8 15 5 1m-6 2 5 1M8 7h8"/>',
    muzzle:'<path d="M7 3h10v18H7zM4 11h3v4H4zM17 11h3v4h-3z"/><path class="badge-detail" d="M10 6h4m-4 4h4m-4 4h4m-4 4h4"/>',
    barrel:'<path d="M9 3h6v18H9zM6 7h12v3H6zM7 17h10v3H7z"/><path class="badge-detail" d="M11 4v11"/>',
    finish:'<path d="m5 5 14 0 0 14H5z"/><path class="badge-detail" d="m6 17 11-11m-11 5 5-5m1 12 6-6"/>',
  };
  return `<svg class="badge-art" x="0" y="0" width="27" height="27" viewBox="0 0 24 24"><circle class="badge-rim" cx="12" cy="12" r="10.5"/><circle class="badge-ring" cx="12" cy="12" r="8.4"/><g class="badge-symbol">${shapes[kind]||shapes.finish}</g></svg>`;
}
