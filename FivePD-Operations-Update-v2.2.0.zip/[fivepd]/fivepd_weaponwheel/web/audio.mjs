// Mechanical Foley: Guns by Gary, CC BY-SA 3.0. See sounds/ATTRIBUTION.txt.
const sounds={compact:new Audio(new URL('./sounds/equip.ogg',import.meta.url).href),long:new Audio(new URL('./sounds/equip-long.ogg',import.meta.url).href)};
for(const sound of Object.values(sounds))sound.preload='auto';
export function playEquip(volume,variant='compact') {
  const gain=Math.min(1,Math.max(0,Number.isFinite(volume)?volume:.32));
  if(gain===0)return;
  for(const sound of Object.values(sounds))sound.pause();
  const equip=sounds[variant]||sounds.compact;
  equip.pause();equip.currentTime=0;equip.volume=gain;
  void equip.play().catch(error=>console.warn('Weapon wheel sound playback unavailable:',error.name));
}
