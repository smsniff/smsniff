-- Fill missing fields when an existing configuration predates the current runtime.
Config=type(Config)=='table' and Config or {}
local defaults={OpenKey='TAB',NativeTabFallback=true,AllowInVehicle=false,AllowMovement=false,RefreshMs=250,MaxOpenMs=30000,ShowHelp=false,ShowWeaponName=false,Scale=.94,Debug=false,EquipSound=true,EquipSoundVolume=.32,ExtraWeapons={},SlotOverrides={}}
for key,value in pairs(defaults)do if Config[key]==nil then Config[key]=value end end
Config.StatusHud=Config.StatusHud or {Enabled=true,Resource='fivepd',Font=4,Scale=.36,X=.5,Y=.971,UtcOffsetHours=9,ShowResourceState=false}

if type(Config.OpenKey)~='string' then Config.OpenKey='TAB' end
if type(Config.ExtraWeapons)~='table' then Config.ExtraWeapons={} end
if type(Config.SlotOverrides)~='table' then Config.SlotOverrides={} end
for _,entry in ipairs({{'Scale',.94,.45,1.4},{'RefreshMs',250,100,1000},{'MaxOpenMs',30000,1000,120000},{'EquipSoundVolume',.32,0,1}})do
    local value=Config[entry[1]]
    if type(value)~='number' or value~=value then value=entry[2]end
    Config[entry[1]]=math.min(entry[4],math.max(entry[3],value))
end
