Config = {}
Config.OpenKey = 'TAB'
Config.AllowInVehicle = false
Config.AllowMovement = false -- Native movement is blocked while the wheel is held.
Config.RefreshMs = 250
Config.MaxOpenMs = 30000 -- Lost focus / key-release recovery.
Config.ShowHelp = false
Config.ShowWeaponName = false
Config.Scale = 0.94 -- Reference-size wheel; sidearms/fist have separate proportions.
Config.Debug = false -- /weaponwheeldebug toggles input/open/close diagnostics in F8.
Config.EquipSound = true
Config.EquipSoundVolume = 0.32 -- 0.0 ~ 1.0; short, dry mechanical click.
Config.StatusHud = {
    Enabled = true,
    Resource = 'fivepd',
    Font = 4, -- GTA's condensed HUD font.
    Scale = 0.36,
    X = 0.5,
    Y = 0.971,
    UtcOffsetHours = 9,
    ShowResourceState = false, -- Version by default; true also shows STARTED/STOPPED.
}

-- Slot 1: left, 2: top, 3: bottom, 4: right, 5: unarmed (centre).
-- Names are WEAPON_* identifiers. Overrides never grant weapons.
Config.SlotOverrides = {
    WEAPON_MICROSMG = 1,
    WEAPON_MINISMG = 1,
    WEAPON_MACHINEPISTOL = 1,
    WEAPON_SMG = 3,
    WEAPON_SMG_MK2 = 3,
    WEAPON_ASSAULTSMG = 3,
    WEAPON_COMBATPDW = 3,
}

-- Add custom addon weapons here, then restart this resource.
-- icon: pistol, microsmg, smg, rifle, shotgun, sniper, heavy, knife, baton,
--       grenade, tool, taser, fist. image can replace the vector icon.
Config.ExtraWeapons = {
    -- { name = 'WEAPON_EXAMPLE', label = '커스텀 권총', slot = 1,
    --   icon = 'pistol', image = 'images/example.png',
    --   components = { 'COMPONENT_EXAMPLE_SUPP' } },
}
