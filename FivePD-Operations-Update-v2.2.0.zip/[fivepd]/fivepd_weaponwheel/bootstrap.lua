-- Register diagnostics before data/UI scripts, so a later startup error remains visible.
WeaponWheelRuntime = {version='1.2.0',stage='bootstrap',uiReady=false,enabled=true,fieldLocked=false}
local resource=GetCurrentResourceName()
print(('[fivepd_weaponwheel 1.2.0] client bootstrap loaded; resource=%s'):format(resource))
RegisterCommand('weaponwheeldebug',function()
    Config=Config or {};Config.Debug=not Config.Debug
    local s=WeaponWheelRuntime
    print(('[fivepd_weaponwheel %s] resource=%s stage=%s ready=%s enabled=%s field_locked=%s other_ui=%s key=%s'):format(
        s.version,resource,s.stage,tostring(s.uiReady),tostring(s.enabled),tostring(s.fieldLocked),tostring(IsNuiFocused()),tostring(Config.OpenKey or 'TAB')))
end,false)
if type(SetTimeout)=='function' then
    SetTimeout(10000,function()
        if WeaponWheelRuntime.stage~='client-ready' then print('[fivepd_weaponwheel] Client startup incomplete. Check the earlier Lua errors and install the complete wheel resource.')
        elseif not WeaponWheelRuntime.uiReady then print('[fivepd_weaponwheel] NUI not ready. Check web/index.html, web/*.mjs and the resource file list.') end
    end)
end
