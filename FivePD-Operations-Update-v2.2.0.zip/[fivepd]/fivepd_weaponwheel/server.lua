-- Server-owned footer data: never trust player-provided counts/version/time.
local event = 'fivepd_weaponwheel:status'
local function snapshot()
    local settings = Config.StatusHud
    local raw = GetResourceMetadata(settings.Resource, 'version', 0) or '?'
    local version = raw:gsub('[^%w%._%-]', '')
    if version == '' then version = '?' end
    local offset = math.floor((settings.UtcOffsetHours or 9) * 3600)
    return {
        version=version,
        state=GetResourceState(settings.Resource),
        players=#GetPlayers(),
        maximum=math.max(1, GetConvarInt('sv_maxclients', 48)),
        time=os.date('!%I:%M %p', os.time()+offset),
    }
end
RegisterNetEvent(event..':request', function()
    if Config.StatusHud.Enabled then TriggerClientEvent(event, source, snapshot()) end
end)
CreateThread(function()
    local last
    while true do
        if Config.StatusHud.Enabled then
            local data = snapshot()
            local key = ('%s|%s|%d|%d|%s'):format(data.version,data.state,data.players,data.maximum,data.time)
            if key ~= last then TriggerClientEvent(event,-1,data);last=key end
        end
        Wait(1000)
    end
end)
