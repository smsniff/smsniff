local resource=GetCurrentResourceName()
local function report()
    print(('[fivepd_weaponwheel 1.2.0] active path: %s'):format(GetResourcePath(resource) or 'missing'))
    local missing={}
    for _,file in ipairs({'bootstrap.lua','config.lua','defaults.lua','weapons.lua','client.lua','web/index.html','web/app.mjs','web/model.mjs','web/icons.mjs','web/catalog.mjs','web/audio.mjs'})do
        if not LoadResourceFile(resource,file)then missing[#missing+1]=file end
    end
    print('[fivepd_weaponwheel] runtime files: '..(#missing==0 and 'complete' or 'MISSING '..table.concat(missing,', ')))
end
RegisterCommand('weaponwheel_status',function(source)if source==0 then report()end end,true)
AddEventHandler('onResourceStart',function(name)if name==resource then report()end end)
