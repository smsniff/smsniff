fx_version 'cerulean'
game 'gta5'

author 'smsniff'
description 'Standalone reference-style weapon wheel for FivePD'
version '1.2.0'

ui_page 'web/index.html'
client_scripts { 'bootstrap.lua', 'config.lua', 'defaults.lua', 'weapons.lua', 'client.lua', 'status_client.lua' }
server_scripts { 'config.lua', 'defaults.lua', 'server.lua', 'server/deployment.lua' }
files { 'web/index.html', 'web/style.css', 'web/model.mjs', 'web/icons.mjs', 'web/catalog.mjs', 'web/audio.mjs', 'web/app.mjs', 'web/health.mjs', 'web/fonts/*', 'web/images/*', 'web/sounds/*' }
