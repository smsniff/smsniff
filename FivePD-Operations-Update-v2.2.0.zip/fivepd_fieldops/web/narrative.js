// One cancellable reveal and a small reusable audio pool; nothing runs between death screens.
const assets = 'https://cfx-nui-fivepd/Libraries/FivePD.Nui/assets/';
export class Narrative {
  constructor() { this.generation = 0; this.sounds = []; this.index = 0; }
  stop() {
    this.generation++;
    clearTimeout(this.timer);
    for (const sound of this.sounds) sound.pause();
  }
  async start(element, text, volume) {
    this.stop();
    const generation = this.generation;
    const letters = Array.from(text);
    element.setAttribute('aria-label', text);
    const fragment = document.createDocumentFragment();
    for (const character of letters) {
      const span = document.createElement('span');
      span.className = 'ink'; span.textContent = character;
      span.setAttribute('aria-hidden', 'true'); fragment.append(span);
    }
    element.replaceChildren(fragment);
    try { await document.fonts.load('500 23px "Field Dispatch Serif"', text); } catch {}
    if (generation !== this.generation) return;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
      for (const span of element.children) span.classList.add('visible');
      return;
    }
    let index = 0;
    const reveal = () => {
      if (generation !== this.generation) return;
      if (index >= letters.length) { this.play(true, volume); return; }
      element.children[index].classList.add('visible');
      const character = letters[index++];
      if (index % 2 && character.trim()) this.play(false, volume);
      this.timer = setTimeout(reveal, character === ' ' ? 170 : /[.!?。]/.test(character) ? 320 : 110);
    };
    this.timer = setTimeout(reveal, 450);
  }
  play(ending, volume) {
    if (volume <= 0 || document.hidden) return;
    if (!this.sounds.length) {
      this.sounds = [new Audio(assets+'audio/field-writing.ogg'), new Audio(assets+'audio/field-writing.ogg'), new Audio(assets+'audio/field-writing.ogg'), new Audio(assets+'audio/field-line-end.ogg')];
      for (const sound of this.sounds) sound.preload = 'auto';
    }
    const sound = this.sounds[ending ? 3 : this.index++ % 3];
    sound.volume = Math.max(0, Math.min(1, volume)) * (ending ? .055 : .035);
    sound.playbackRate = ending ? 1 : .96 + this.index % 3 * .025;
    sound.currentTime = 0;
    void sound.play().catch(() => {});
  }
}
