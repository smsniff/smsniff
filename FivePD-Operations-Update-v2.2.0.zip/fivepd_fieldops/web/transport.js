// NUI callbacks are the only outbound transport; the server derives the player identity.
const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'fivepd_fieldops';
export async function request(action, extra = {}, endpoint = 'fivepd:fieldops:action') {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12500);
  try {
    const response = await fetch(`https://${resource}/${endpoint}`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({Action: action, ...extra}), signal: controller.signal,
    });
    let result = await response.json();
    if (typeof result === 'string') result = JSON.parse(result);
    return result;
  } catch {
    return {Status: false, Message: '서버 연결을 확인하고 다시 시도해 주세요.'};
  } finally { clearTimeout(timeout); }
}
