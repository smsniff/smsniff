-- Console-only path probe, independent of the core assembly's bootstrap.
local function report()
    print(('[FivePD active] core = %s'):format(GetResourcePath('fivepd') or 'missing'))
    print(('[FivePD active] core update = %s'):format(GetResourceMetadata('fivepd', 'operations_update', 0) or 'older package'))
    print(('[FivePD active] fieldops = %s'):format(GetResourcePath(GetCurrentResourceName()) or 'missing'))
    print(('[FivePD active] wheel = %s (version %s)'):format(GetResourcePath('fivepd_weaponwheel') or 'missing',GetResourceMetadata('fivepd_weaponwheel','version',0) or 'missing'))
end
RegisterCommand('fivepd_active_path', function(source)
    if source == 0 then report() end
end, true)
AddEventHandler('onResourceStart', function(name)
    if name == GetCurrentResourceName() then report() end
end)
