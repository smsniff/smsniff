-- Physical AI rescue: server-created entities, road spawn, driving and on-foot CPR.
-- The client never authorizes an arrival or a completed revival.
local missions = {}
local stopping = false
local ambulanceModel, medicModel = joaat('ambulance'), joaat('s_m_m_paramedic_01')
local function distance(a,b)return #(a-b)end
local function point(p)return vector3(p.X,p.Y,p.Z)end
local function control(entity)
    if not DoesEntityExist(entity) then return false end
    if NetworkHasControlOfEntity(entity) then return true end
    NetworkRequestControlOfEntity(entity)
    return NetworkHasControlOfEntity(entity)
end
local function loadModel(model)
    if not IsModelInCdimage(model) then return false end
    RequestModel(model)
    local deadline=GetGameTimer()+5000
    while not HasModelLoaded(model) and GetGameTimer()<deadline and not stopping do Wait(50) end
    return HasModelLoaded(model)
end
local function route(mission)
    if mission.routeBusy then return end
    mission.routeBusy=true
    CreateThread(function()
        if not loadModel(ambulanceModel) or not loadModel(medicModel) then mission.routeBusy=false;return end
        local patient=point(mission.Patient)
        local rotation=GetGameplayCamRot(2)
        local chosen,chosenHeading
        for _,radius in ipairs({330.0,290.0,380.0}) do
            for _,offset in ipairs({180,150,210,120,240,90,270,0}) do
                local angle=math.rad(rotation.z+offset)
                local x,y=patient.x+math.sin(angle)*radius,patient.y+math.cos(angle)*radius
                local found,node,heading=GetClosestVehicleNodeWithHeading(x,y,patient.z,1,3.0,0)
                if found and distance(node,patient)>=240 and distance(node,patient)<=420 and math.abs(node.z-patient.z)<=90 then
                    local visible=IsSphereVisible(node.x,node.y,node.z,8.0)
                    if not visible then chosen,chosenHeading=node,heading;break end
                    if not chosen then chosen,chosenHeading=node,heading end
                end
            end
            if chosen then break end
        end
        if chosen and not stopping and mission.Stage=='finding-route' then
            TriggerServerEvent('fivepd:fieldops:request',json.encode({Action='ems-route',RequestId='ems-'..mission.Ticket..'-'..GetGameTimer(),Ticket=mission.Ticket,
                Position={X=chosen.x,Y=chosen.y,Z=chosen.z},Heading=chosenHeading}))
        end
        mission.routeBusy=false
    end)
end
local function resolve(mission)
    local vehicle=NetworkGetEntityFromNetworkId(mission.Vehicle or 0)
    local driver=NetworkGetEntityFromNetworkId(mission.Driver or 0)
    local medic=NetworkGetEntityFromNetworkId(mission.Medic or 0)
    if not DoesEntityExist(vehicle) or not DoesEntityExist(driver) or not DoesEntityExist(medic) then return end
    if GetEntityModel(vehicle)~=ambulanceModel or GetEntityModel(driver)~=medicModel or GetEntityModel(medic)~=medicModel then return end
    return vehicle,driver,medic
end
local function setup(vehicle,driver,medic)
    SetVehicleDoorsLocked(vehicle,2)
    SetVehicleEngineOn(vehicle,true,true,false)
    SetBlockingOfNonTemporaryEvents(driver,true);SetBlockingOfNonTemporaryEvents(medic,true)
    SetPedCanBeDraggedOut(driver,false);SetPedCanBeDraggedOut(medic,false)
    SetDriverAbility(driver,1.0);SetDriverAggressiveness(driver,0.0)
    RemoveAllPedWeapons(driver,true);RemoveAllPedWeapons(medic,true)
    SetPedIntoVehicle(driver,vehicle,-1);SetPedIntoVehicle(medic,vehicle,0)
    SetVehicleSiren(vehicle,true)
end
local function work(mission)
    if mission.worker then return end
    mission.worker=true
    CreateThread(function()
        local lastDrive,lastWalk,retireStarted=0,0,nil
        while not stopping and not mission.ended and GetGameTimer()-mission.startedAt<420000 do
            local vehicle,driver,medic=resolve(mission)
            if vehicle and control(vehicle) and control(driver) and control(medic) then
                if not mission.setup then setup(vehicle,driver,medic);mission.setup=true end
                if mission.clearCpr then ClearPedTasks(medic);mission.clearCpr=false;mission.cpr=false end
                local patient=point(mission.Patient)
                local stage=mission.Stage
                local now=GetGameTimer()
                if stage=='enroute' then
                    local d=distance(GetEntityCoords(vehicle),patient)
                    if d>32 then
                        SetVehicleHandbrake(vehicle,false)
                        if now-lastDrive>12000 or lastDrive==0 then
                            local target=patient
                            local found,node=GetClosestVehicleNodeWithHeading(patient.x,patient.y,patient.z,1,3.0,0)
                            if found and distance(node,patient)<30 then target=node end
                            TaskVehicleDriveToCoordLongrange(driver,vehicle,target.x,target.y,target.z,19.0,786603,10.0)
                            lastDrive=now
                        end
                    else
                        SetVehicleSiren(vehicle,false)
                        if GetEntitySpeed(vehicle)>1.0 then TaskVehicleTempAction(driver,vehicle,27,1500)
                        else
                            SetVehicleHandbrake(vehicle,true)
                            if IsPedInVehicle(medic,vehicle,false) then
                                if now-lastWalk>4000 or lastWalk==0 then TaskLeaveVehicle(medic,vehicle,0);lastWalk=now end
                            elseif distance(GetEntityCoords(medic),patient)>2.0 and (now-lastWalk>7000 or lastWalk==0) then
                                TaskFollowNavMeshToCoord(medic,patient.x,patient.y,patient.z,1.25,45000,1.5,false,0.0)
                                lastWalk=now
                            end
                        end
                    end
                elseif stage=='treating' and not mission.cpr then
                    SetVehicleSiren(vehicle,false)
                    RequestAnimDict('mini@cpr@char_a@cpr_str')
                    local deadline=now+3000
                    while not HasAnimDictLoaded('mini@cpr@char_a@cpr_str') and GetGameTimer()<deadline and not stopping do Wait(50) end
                    if mission.Stage=='treating' and HasAnimDictLoaded('mini@cpr@char_a@cpr_str') then
                        TaskTurnPedToFaceCoord(medic,patient.x,patient.y,patient.z,500);Wait(450)
                        if mission.Stage=='treating' then TaskPlayAnim(medic,'mini@cpr@char_a@cpr_str','cpr_pumpchest',4.0,-4.0,-1,1,0.0,false,false,false);mission.cpr=true end
                    end
                elseif stage=='hold' then
                    if mission.cpr then ClearPedTasks(medic);mission.cpr=false end
                    SetVehicleSiren(vehicle,false)
                elseif stage=='retiring' or stage=='failed' then
                    mission.endedSoon=true
                    SetVehicleSiren(vehicle,false);SetVehicleHandbrake(vehicle,false)
                    if not retireStarted then
                        ClearPedTasks(medic);TaskEnterVehicle(medic,vehicle,9000,0,1.2,1,0);retireStarted=now
                    end
                    if now-retireStarted>9500 or IsPedInVehicle(medic,vehicle,false) then
                        if not mission.returning then
                            local home=point(mission.Start)
                            TaskVehicleDriveToCoordLongrange(driver,vehicle,home.x,home.y,home.z,15.0,786603,8.0)
                            mission.returning=true
                        end
                    end
                end
            elseif mission.setup and (mission.Stage=='retiring' or mission.Stage=='failed') then
                mission.ended=true
            end
            Wait(500)
        end
        mission.worker=false
        if missions[mission.Ticket]==mission then missions[mission.Ticket]=nil end
        SetModelAsNoLongerNeeded(ambulanceModel);SetModelAsNoLongerNeeded(medicModel)
    end)
end
RegisterNetEvent('fivepd:fieldops:ems',function(serialized)
    local ok,data=pcall(json.decode,serialized)
    if not ok or type(data)~='table' or type(data.Ticket)~='string' then return end
    local mission=missions[data.Ticket] or {}
    if mission.endedSoon and data.Stage~='retiring' and data.Stage~='failed' then return end
    if mission.Stage~=data.Stage and mission.cpr then
        local _,_,medic=resolve(mission)
        if medic and control(medic) then ClearPedTasks(medic) end
        mission.cpr=false;mission.clearCpr=true
    end
    for key,value in pairs(data) do mission[key]=value end
    mission.startedAt=mission.startedAt or GetGameTimer()
    missions[data.Ticket]=mission
    if data.Stage=='finding-route' then route(mission)
    elseif data.Vehicle and data.Vehicle~=0 then work(mission) end
end)
RegisterNetEvent('fivepd:fieldops:emsStop',function(ticket)
    local mission=missions[ticket]
    if mission then mission.ended=true;missions[ticket]=nil end
end)

AddEventHandler('onClientResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    stopping=true
    for _,mission in pairs(missions) do mission.ended=true end
    -- Entity cleanup belongs to the server, which verifies each recorded network ID/model.
end)

RegisterNetEvent('fivepd:fieldops:emsFade',function(serialized)
    local ok,data=pcall(json.decode,serialized)
    if not ok or type(data)~='table' then return end
    for _,netId in ipairs({data.VehicleNet,data.DriverNet,data.MedicNet}) do
        if type(netId)=='number' and netId~=0 then
            local entity=NetworkGetEntityFromNetworkId(netId)
            if DoesEntityExist(entity) and (GetEntityModel(entity)==ambulanceModel or GetEntityModel(entity)==medicModel) then NetworkFadeOutEntity(entity,false,false) end
        end
    end
end)
