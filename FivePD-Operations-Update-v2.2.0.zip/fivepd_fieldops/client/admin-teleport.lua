-- Coordinates/identity/permissions are approved again by the server after ground streaming.
local job
local resource=GetCurrentResourceName()
local function stop(token)
    if not job or (token and token~=job.Token)then return end
    job.cancelled=true;job=nil
    NewLoadSceneStop();FreezeEntityPosition(PlayerPedId(),false)
    if IsScreenFadedOut() or IsScreenFadingOut()then DoScreenFadeIn(350)end
    TriggerEvent('fivepd:fieldops:teleportLock',false)
end
local function request(action,data)
    data=data or {};data.Action=action
    TriggerEvent('fivepd:fieldops:clientRequest',json.encode(data),function(serialized)
        local ok,reply=pcall(json.decode,serialized)
        if ok and reply.Status==false then
            TriggerEvent('chat:addMessage',{args={'관리자 이동',reply.Message or '이동을 취소했습니다.'}})
            stop()
        end
    end)
end
RegisterNetEvent('fivepd:fieldops:teleportProbe',function(serialized)
    if source~=65535 then return end
    local ok,data=pcall(json.decode,serialized)
    if not ok or type(data)~='table' or type(data.Token)~='string' or job then return end
    job=data;local current=job
    TriggerEvent('fivepd:fieldops:teleportLock',true)
    CreateThread(function()
        if job~=current or current.cancelled then return end
        DoScreenFadeOut(200)
        local ped=PlayerPedId();FreezeEntityPosition(ped,true)
        local p=data.Target
        RequestCollisionAtCoord(p.X,p.Y,p.Z)
        NewLoadSceneStartSphere(p.X,p.Y,data.KnownHeight and p.Z or 100.0,70.0,0)
        local deadline=GetGameTimer()+6500
        local found,height=data.KnownHeight,p.Z
        while job==current and not current.cancelled and GetGameTimer()<deadline do
            RequestCollisionAtCoord(p.X,p.Y,data.KnownHeight and p.Z or 100.0)
            if not found then found,height=GetGroundZFor_3dCoord(p.X,p.Y,1000.0,false)end
            if found and IsNewLoadSceneLoaded()then break end
            Wait(100)
        end
        if job~=current or current.cancelled then return end
        if not found or not IsNewLoadSceneLoaded()then
            TriggerEvent('chat:addMessage',{args={'관리자 이동','지면을 확인할 수 없어 이동을 취소했습니다.'}})
            request('admin-teleport-cancel');stop(data.Token);return
        end
        local water,waterHeight=GetWaterHeightNoWaves(p.X,p.Y,1000.0)
        if not data.KnownHeight and water and height<waterHeight-1.0 then request('admin-teleport-cancel');stop(data.Token);return end
        request('admin-teleport-ready',{Token=data.Token,Z=height})
        local responseDeadline=GetGameTimer()+4000
        while job==current and not current.cancelled and GetGameTimer()<responseDeadline do Wait(100)end
        if job==current then request('admin-teleport-cancel');stop(data.Token)end
    end)
end)
RegisterNetEvent('fivepd:fieldops:teleportDone',function(serialized)
    if source~=65535 then return end
    local ok,data=pcall(json.decode,serialized)
    if not ok or not job or data.Token~=job.Token then return end
    local current=job
    CreateThread(function()
        if job~=current or current.cancelled then return end
        local p=data.Position
        SetEntityCoordsNoOffset(PlayerPedId(),p.X,p.Y,p.Z,false,false,false)
        RequestCollisionAtCoord(p.X,p.Y,p.Z)
        local deadline=GetGameTimer()+2500
        while job==current and not HasCollisionLoadedAroundEntity(PlayerPedId()) and GetGameTimer()<deadline do Wait(50)end
        stop(data.Token)
    end)
end)
RegisterNetEvent('fivepd:fieldops:teleportAbort',function(token)
    if source==65535 then stop(token)end
end)
RegisterNetEvent('fivepd:fieldops:state',function(serialized)
    if not job then return end
    local ok,data=pcall(json.decode,serialized)
    if ok and data.Phase~='active'then stop()end
end)
AddEventHandler('onClientResourceStop',function(name)if name==resource then stop()end end)
