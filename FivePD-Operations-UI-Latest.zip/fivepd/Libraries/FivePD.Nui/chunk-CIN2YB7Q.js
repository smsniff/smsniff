import{T as o}from"./chunk-O6ZBGKRU.js";var t=new o("Callsign format items");export{t as a};
