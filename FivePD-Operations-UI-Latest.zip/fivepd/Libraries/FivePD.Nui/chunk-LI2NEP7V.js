import{a as t,b as r}from"./chunk-O6ZBGKRU.js";function l(i,e){return r(t({},i),{Filters:t(t({},i.Filters),e)})}export{l as a};
