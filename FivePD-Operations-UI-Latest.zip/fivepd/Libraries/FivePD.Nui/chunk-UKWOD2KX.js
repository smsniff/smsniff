import{V as o,Y as n,ca as r,i as e}from"./chunk-O6ZBGKRU.js";function s(){n(s);let c=o(r),t=new e(1);return c.onDestroy(()=>{t.next(),t.complete()}),t}export{s as a};
