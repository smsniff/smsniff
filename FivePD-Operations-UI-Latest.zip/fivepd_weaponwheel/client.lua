local resource = GetCurrentResourceName()
local UNARMED = joaat('WEAPON_UNARMED') & 0xffffffff
local opened, uiReady, enabled, releaseRequested = false, false, true, false
local session, openedAt, releaseAt, pedAtOpen = 0, 0, 0, 0
local fieldLocked=false
local uiInstance
local weapons, componentNames, groupSlots, componentSupport = {}, {}, {}, {}
local function unsigned(hash) return hash & 0xffffffff end
local function trace(message)
    if Config.Debug then print(('[fivepd_weaponwheel 1.1.1] %s'):format(message)) end
end
local function send(action, data)
    data = data or {}
    data.resource, data.action, data.session = 'fivepd_weaponwheel', action, session
    SendNUIMessage(data)
end

for _, row in ipairs(WeaponDefinitions) do weapons[#weapons + 1] = row end
for _, row in ipairs(Config.ExtraWeapons) do
    local entry = {}
    for k, v in pairs(row) do entry[k] = v end
    entry.hash = unsigned(joaat(entry.name))
    weapons[#weapons + 1] = entry
end
for name, slot in pairs({GROUP_PISTOL=1,GROUP_SMG=3,GROUP_RIFLE=2,GROUP_MG=2,
    GROUP_SNIPER=2,GROUP_SHOTGUN=3,GROUP_HEAVY=3,GROUP_THROWN=3,
    GROUP_MELEE=4,GROUP_PETROLCAN=4,GROUP_FIREEXTINGUISHER=4,GROUP_STUNGUN=1}) do
    groupSlots[unsigned(joaat(name))] = slot
end
local function componentEntry(name)
    local meta = WeaponComponentDefinitions[name] or {}
    return {name=name, hash=unsigned(joaat(name)), kind=meta.kind, label=meta.label, variant=meta.variant}
end
for _, name in ipairs(WeaponComponents) do componentNames[#componentNames + 1] = componentEntry(name) end
local function canUse(ped)
    return enabled and not fieldLocked and ped ~= 0 and DoesEntityExist(ped) and not IsEntityDead(ped)
        and not IsPauseMenuActive() and not IsPlayerSwitchInProgress()
        and not IsScreenFadedOut() and (Config.AllowInVehicle or not IsPedInAnyVehicle(ped, false))
end
local function inventory(ped)
    local result = {}
    local seen = {}
    for _, weapon in ipairs(weapons) do
        local hash = unsigned(weapon.hash)
        if not seen[hash] and (hash == UNARMED or HasPedGotWeapon(ped, hash, false)) then
            seen[hash] = true
            local group = unsigned(GetWeapontypeGroup(hash))
            local slot = hash == UNARMED and 5 or Config.SlotOverrides[weapon.name] or weapon.slot or groupSlots[group] or 4
            if slot < 1 or slot > 5 or slot == 5 and hash ~= UNARMED then slot = 4 end
            local components, componentDetails = {}, {}
            if not componentSupport[hash] then
                local supported, candidates = {}, {}
                -- Vanilla rows carry exact compatible candidates. Addon rows can
                -- supply their own names or fall back to the known catalog.
                if weapon.components then
                    for _, name in ipairs(weapon.components) do candidates[#candidates+1] = componentEntry(name) end
                else
                    for _, row in ipairs(componentNames) do candidates[#candidates+1] = row end
                end
                for _, component in ipairs(candidates) do
                    if DoesWeaponTakeWeaponComponent(hash, component.hash) then supported[#supported+1] = component end
                end
                componentSupport[hash] = supported
            end
            for _, component in ipairs(componentSupport[hash]) do
                local kind = component.kind or (component.name:find('FLSH') and 'light'
                    or component.name:find('SUPP') and 'suppressor'
                    or component.name:find('CLIP') and not component.name:find('CLIP_01') and 'magazine')
                if kind then
                    local installed = HasPedGotWeaponComponent(ped, hash, component.hash)
                    components[kind] = components[kind] or installed
                    if installed then componentDetails[kind] = {name=component.name,label=component.label or kind,variant=component.variant or kind} end
                end
            end
            local hasClip, clip = GetAmmoInClip(ped, hash)
            local total = GetAmmoInPedWeapon(ped, hash)
            local melee = group == unsigned(joaat('GROUP_MELEE')) or hash == UNARMED
            result[#result+1] = {
                hash=hash, slot=slot, icon=weapon.icon, label=weapon.label,
                image=weapon.image, components=components, componentDetails=componentDetails,
                hasAmmo=not melee and (hasClip or total > 0),
                clip=hasClip and clip or 0, total=total,
            }
        end
    end
    return result
end
local function close(commit, hash, reason)
    if not opened then return end
    opened, releaseRequested = false, false
    -- This resource never takes browser focus. Do not clear another UI's focus.
    trace(('close session=%d commit=%s reason=%s'):format(session, tostring(commit), reason or 'selection'))
    send('hide')
    local ped = PlayerPedId()
    if not commit or ped ~= pedAtOpen or not canUse(ped) or type(hash) ~= 'number' or hash % 1 ~= 0 then return end
    hash = unsigned(hash)
    -- Only a weapon listed in this wheel AND still owned may be equipped.
    for _, item in ipairs(inventory(ped)) do
        if item.hash == hash and (hash == UNARMED or HasPedGotWeapon(ped, hash, false)) then
            local previous = unsigned(GetSelectedPedWeapon(ped))
            SetCurrentPedWeapon(ped, hash, true)
            if Config.EquipSound and hash ~= UNARMED and previous ~= hash then
                local long = item.icon=='rifle' or item.icon=='shotgun' or item.icon=='sniper' or item.icon=='smg' or item.icon=='heavy'
                send('equipped', {volume=math.min(1.0, math.max(0.0, Config.EquipSoundVolume)),sound=long and 'long' or 'compact'})
            end
            return
        end
    end
end
AddEventHandler('fivepd:fieldops:clientLock', function(locked)
    fieldLocked=locked==true
    if fieldLocked then close(false,nil,'field_recovery') end
end)

local function open()
    local ped = PlayerPedId()
    if opened or not uiReady or not canUse(ped) or IsNuiFocused() then
        trace(('open ignored ready=%s active=%s other_ui=%s'):format(tostring(uiReady), tostring(opened), tostring(IsNuiFocused())))
        return
    end
    session, openedAt, pedAtOpen = session + 1, GetGameTimer(), ped
    opened, releaseRequested = true, false
    SetCursorLocation(0.5, 0.515)
    trace(('open session=%d'):format(session))
    send('open', {items=inventory(ped), equipped=unsigned(GetSelectedPedWeapon(ped)),
        inputMode='game', scale=Config.Scale, help=Config.ShowHelp, weaponName=Config.ShowWeaponName})
end

RegisterNUICallback('ready', function(data, cb)
    -- Retried readiness for the same document must not dismiss a held wheel.
    if opened and uiInstance ~= data.instance then close(false, nil, 'ui_reload') end
    uiInstance = data.instance
    uiReady = true
    cb({ok=true})
end)
RegisterNUICallback('close', function(data, cb)
    if opened and data.session == session then close(data.commit == true, data.hash, 'ui_result') end
    cb({ok=true})
end)
RegisterCommand('+fivepd_weaponwheel', open, false)
RegisterCommand('-fivepd_weaponwheel', function()
    if opened and not releaseRequested then
        releaseRequested, releaseAt = true, GetGameTimer()
        trace(('key released session=%d'):format(session))
        -- The frontend sends the final hovered/cycled hash; avoid selecting a stale hash.
        send('release')
    end
end, false)
RegisterKeyMapping('+fivepd_weaponwheel', 'FivePD 무기 선택창 (누르고 있기)', 'keyboard', Config.OpenKey)
RegisterCommand('weaponwheel', function()
    enabled = not enabled
    if not enabled then close(false) end
    TriggerEvent('chat:addMessage', {args={'무기 선택창', enabled and '사용 설정됨' or '사용 해제됨 (기본 무기 선택창 복원)'}})
end, false)
exports('setEnabled', function(value)
    enabled = value == true
    if not enabled then close(false) end
end)
RegisterCommand('weaponwheeldebug', function()
    Config.Debug = not Config.Debug
    print(('[fivepd_weaponwheel 1.1.1] debug=%s ready=%s active=%s other_ui=%s'):format(
        tostring(Config.Debug), tostring(uiReady), tostring(opened), tostring(IsNuiFocused())))
end, false)

CreateThread(function()
    while true do
        if opened then
            local ped, now = PlayerPedId(), GetGameTimer()
            if IsNuiFocused() then
                close(false, nil, 'other_ui')
            elseif ped ~= pedAtOpen or not canUse(ped) then
                close(false, nil, 'player_state')
            elseif now-openedAt > Config.MaxOpenMs then
                close(false, nil, 'max_open_time')
            elseif releaseRequested and now-releaseAt > 750 then
                close(false, nil, 'release_callback_timeout')
            end
        end
        Wait(100)
    end
end)
CreateThread(function()
    while true do
        if opened then
            send('inventory', {items=inventory(PlayerPedId())})
            Wait(math.max(100, Config.RefreshMs))
        else Wait(250) end
    end
end)
CreateThread(function()
    local lastX, lastY, inputSession
    local shortcuts = {[157]=1, [158]=2, [160]=3, [164]=4, [165]=5}
    while true do
        if enabled then
            -- Suppress the original wheel only when ours can actually open.
            local ped = PlayerPedId()
            if opened or uiReady and canUse(ped) and not IsNuiFocused() then
                DisableControlAction(0, 37, true)
                HideHudComponentThisFrame(19)
                HideHudComponentThisFrame(20)
            end
            if opened then
                for _, control in ipairs({1,2,14,15,16,17,24,25,37,45,68,69,70,91,92,
                    114,140,141,142,143,157,158,159,160,161,162,163,164,165,177,200,202,
                    239,240,241,242,257,261,262,322}) do
                    DisableControlAction(0, control, true)
                end
                if not Config.AllowMovement then
                    for _, control in ipairs({21,22,30,31,36}) do DisableControlAction(0, control, true) end
                end
                DisablePlayerFiring(PlayerId(), true)
                -- Native cursor/input work without moving keyboard ownership into CEF.
                SetMouseCursorActiveThisFrame()
                SetMouseCursorSprite(1)
                if IsDisabledControlJustPressed(0, 200) or IsDisabledControlJustPressed(0, 202)
                    or IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 322) then
                    close(false, nil, 'escape')
                elseif not releaseRequested then
                    local x, y = GetDisabledControlNormal(0, 239), GetDisabledControlNormal(0, 240)
                    local cycle, slot = 0, nil
                    if IsDisabledControlJustPressed(0, 14) or IsDisabledControlJustPressed(0, 242) then cycle = 1 end
                    if IsDisabledControlJustPressed(0, 15) or IsDisabledControlJustPressed(0, 241) then cycle = -1 end
                    for control, value in pairs(shortcuts) do
                        if IsDisabledControlJustPressed(0, control) then slot = value end
                    end
                    local moved = inputSession ~= session or x ~= lastX or y ~= lastY
                    if moved or cycle ~= 0 or slot then
                        send('input', {x=moved and x or nil, y=moved and y or nil, cycle=cycle, slot=slot})
                    end
                    lastX, lastY, inputSession = x, y, session
                end
            end
            Wait(0)
        else Wait(200) end
    end
end)
AddEventHandler('onResourceStop', function(name)
    if name == resource and opened then close(false) end
end)
