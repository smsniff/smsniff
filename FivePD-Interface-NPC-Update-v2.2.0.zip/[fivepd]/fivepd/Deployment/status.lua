-- Read-only deployment identity. No timers, DB writes, player identifiers or gameplay events.
local resource = GetCurrentResourceName()
local packageVersion = '2.2.0'
local uiEntry = 'main-FF7OWQQT.js'

local function report(includeFieldState)
    print(('[FivePD UPDATE %s] resource=%s'):format(packageVersion, resource))
    print(('[FivePD UPDATE] active path: %s'):format(GetResourcePath(resource) or 'unknown'))
    local index = LoadResourceFile(resource, 'Libraries/FivePD.Nui/index.html')
    local currentUi = index and index:find(uiEntry, 1, true) ~= nil
    print(('[FivePD UPDATE] UI files: %s'):format(currentUi and '2.2.0 UI present' or 'MISMATCH - check update destination'))
    if includeFieldState then
        print(('[FivePD UPDATE] fivepd_fieldops: %s'):format(GetResourceState('fivepd_fieldops')))
    end
end

RegisterCommand('fivepd_update_status', function(source)
    if source ~= 0 then return end
    report(true)
end, true)

AddEventHandler('onResourceStart', function(name)
    if name == resource then report(false) end
end)
