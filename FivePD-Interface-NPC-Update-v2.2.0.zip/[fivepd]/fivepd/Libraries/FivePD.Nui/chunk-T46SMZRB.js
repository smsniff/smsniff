import{V as o}from"./chunk-C7EC5UHB.js";var t=new o("Callsign format items");export{t as a};
