import{X as o,_ as n,ea as r,i as e}from"./chunk-C7EC5UHB.js";function s(){n(s);let c=o(r),t=new e(1);return c.onDestroy(()=>{t.next(),t.complete()}),t}export{s as a};
