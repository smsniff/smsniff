fx_version 'cerulean'
game 'gta5'
author 'FivePD Korean'
description 'Field lifecycle: station entry, injury recovery and physical EMS'
version '1.1.0'
dependency 'fivepd'
ui_page 'web/index.html'
client_scripts {'client/uniform-presets.lua', 'client/stations.lua', 'client/lifecycle.lua', 'client/wardrobe.lua', 'client/ems.lua', 'client/admin-teleport.lua'}
server_script 'server/deployment.lua'
files {'web/**/*', 'assets/mission-row.png'}
