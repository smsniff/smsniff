import {request} from './transport.js';

const panel=document.querySelector('#wardrobe');
panel.innerHTML=`<header><div><span class="wardrobe-kicker">피복 담당관</span><h1>라커룸</h1></div><button id="wardrobe-close" aria-label="라커룸 닫기">×</button></header>
<p class="wardrobe-station"></p><p class="wardrobe-intro">근무 준비를 도와드리겠습니다.<br>보관한 원래 복장으로 언제든 돌아갈 수 있습니다.</p>
<div class="wardrobe-options"><button data-preset="patrol"><span><strong>순찰 근무복</strong><small>셔츠 · 근무 바지 · 구두</small></span><span aria-hidden="true">↗</span></button><button data-preset="patrol-cap"><span><strong>순찰 근무복 · 근무모</strong><small>기본 근무복과 경찰 모자</small></span><span aria-hidden="true">↗</span></button><button data-preset="restore"><span><strong>원래 복장으로 복귀</strong><small>라커에 보관한 의상 착용</small></span><span aria-hidden="true">↶</span></button></div>
<p id="wardrobe-support" hidden>현재 모델에는 호환되는 근무복이 없습니다. 기본 프리모드 남성·여성 캐릭터를 지원하며, 얼굴 보존을 위해 모델을 강제로 바꾸지 않습니다.</p><p id="wardrobe-message" role="status" aria-live="polite"></p><footer><span>얼굴 · 머리 · 장비 유지</span><span>닫기 <kbd>ESC</kbd></span></footer>`;
let current;
function render(data) {
  current=data;panel.hidden=!data.Open;
  panel.querySelector('.wardrobe-station').textContent=data.Station||'';
  panel.querySelector('#wardrobe-support').hidden=data.Supported!==false;
  panel.querySelector('#wardrobe-message').textContent=data.Busy?'복장을 갈아입는 중입니다…':data.Message||'';
  for(const button of panel.querySelectorAll('[data-preset]')) button.disabled=!!data.Busy||(button.dataset.preset==='restore'?!data.CanRestore:data.Supported===false);
  panel.classList.toggle('busy',!!data.Busy);
}
async function close() {
  if(panel.hidden)return;
  const result=await request('close',{},'fivepd:station:close');
  if(result.Status)panel.hidden=true;
}
panel.querySelector('#wardrobe-close').addEventListener('click',close);
for(const button of panel.querySelectorAll('[data-preset]')) button.addEventListener('click',async()=>{
  if(!current||current.Busy)return;
  render({...current,Busy:true});
  const result=await request('select',{Preset:button.dataset.preset},'fivepd:station:uniform');
  if(result.Status===false)render({...current,Busy:false,Message:result.Message||'복장을 변경하지 못했습니다.'});
});
window.addEventListener('message',({data})=>{if(data?.Event==='fivepd:station:wardrobe')render(data);});
window.addEventListener('keydown',event=>{
  if(panel.hidden)return;
  if(event.code==='Escape'){event.preventDefault();event.stopImmediatePropagation();void close();}
});
