local state, panel, original = nil, nil, nil
local busy, stopping, epoch = false, false, 0
local statusMessage=''

local function presetFor(ped)
    local model=GetEntityModel(ped)
    for name,preset in pairs(FivePDUniforms) do if model==GetHashKey(name) then return preset end end
end
local function publish(message)
    if message~=nil then statusMessage=message end
    SendNUIMessage({Event='fivepd:station:wardrobe',Open=panel~=nil,Station=panel and panel.name,
        Supported=presetFor(PlayerPedId())~=nil,CanRestore=original~=nil,Busy=busy,Message=statusMessage})
end
local function close(keepFocus)
    if not panel then return end
    panel=nil;epoch=epoch+1;busy=false
    TriggerEvent('fivepd:fieldops:wardrobeLock',false)
    if not keepFocus then SetNuiFocus(false,false) end
    publish('')
end
local function validPlace()
    if not panel or not state or state.Phase~='active' or state.Reviving or not state.CanUseStations then return false end
    local ped=PlayerPedId()
    if IsEntityDead(ped) or GetEntityHealth(ped)<=100 or IsPedInAnyVehicle(ped,false) then return false end
    for _,station in ipairs(state.Stations or {}) do
        local p=station.LockerPosition
        if station.Id==panel.id and p and #(GetEntityCoords(ped)-vector3(p.X,p.Y,p.Z))<2.4 then return true end
    end
    return false
end
local function snapshot(ped,preset)
    local saved={model=GetEntityModel(ped),components={},hat={GetPedPropIndex(ped,0),GetPedPropTextureIndex(ped,0)}}
    for slot in pairs(preset.components) do
        saved.components[slot]={GetPedDrawableVariation(ped,slot),GetPedTextureVariation(ped,slot),GetPedPaletteVariation(ped,slot)}
    end
    return saved
end
local function restore(ped)
    if not original or original.model~=GetEntityModel(ped) then return false end
    for slot,v in pairs(original.components) do SetPedComponentVariation(ped,slot,v[1],v[2],v[3]) end
    if original.hat[1]<0 then ClearPedProp(ped,0) else SetPedPropIndex(ped,0,original.hat[1],original.hat[2],true) end
    original=nil
    return true
end
AddEventHandler('fivepd:fieldops:localState',function(data)
    state=data
    if panel and not validPlace() then close(data.Phase~='active') end
end)
AddEventHandler('fivepd:fieldops:teleportLock',function(locked) if locked then close(false) end end)
AddEventHandler('fivepd:fieldops:stationReady',function() if panel then publish() end end)

RegisterNetEvent('fivepd:fieldops:wardrobe',function(id,name)
    if type(id)~='string' or type(name)~='string' then return end
    panel={id=id,name=name};epoch=epoch+1
    if not validPlace() then panel=nil;return end
    TriggerEvent('fivepd:fieldops:wardrobeLock',true)
    SetNuiFocus(true,true)
    publish('')
end)
RegisterNetEvent('fivepd:fieldops:uniform',function(selection,stationId)
    if not validPlace() or panel.id~=stationId then return end
    local ped=PlayerPedId()
    if selection=='restore' then
        publish(restore(ped) and '보관한 원래 복장으로 갈아입었습니다.' or '복원할 복장이 없거나 캐릭터 모델이 변경되었습니다.')
        return
    end
    if selection~='patrol' and selection~='patrol-cap' then return end
    local preset=presetFor(ped)
    if not preset then publish('이 캐릭터에는 맞는 근무복이 없습니다. 얼굴을 유지하기 위해 캐릭터 모델을 바꾸지 않았습니다.');return end
    for slot,v in pairs(preset.components) do
        if not IsPedComponentVariationValid(ped,slot,v[1],v[2]) then publish('현재 의상 데이터에 맞지 않는 근무복입니다. 복장을 변경하지 않았습니다.');return end
    end
    if selection=='patrol-cap' and (preset.cap[1]>=GetNumberOfPedPropDrawableVariations(ped,0) or preset.cap[2]>=GetNumberOfPedPropTextureVariations(ped,0,preset.cap[1])) then publish('현재 캐릭터에 맞는 근무모가 없습니다.');return end
    if not original or original.model~=GetEntityModel(ped) then original=snapshot(ped,preset) end
    for slot,v in pairs(preset.components) do SetPedComponentVariation(ped,slot,v[1],v[2],0) end
    if selection=='patrol-cap' then SetPedPropIndex(ped,0,preset.cap[1],preset.cap[2],true) else ClearPedProp(ped,0) end
    publish('순찰 근무복으로 갈아입었습니다.')
end)
RegisterNUICallback('fivepd:station:close',function(_,cb) close(false);cb({Status=true}) end)
RegisterNUICallback('fivepd:station:uniform',function(data,cb)
    if busy or not validPlace() or type(data)~='table' or not ({patrol=true,['patrol-cap']=true,restore=true})[data.Preset] then cb({Status=false});return end
    local choice,version,id=data.Preset,epoch,panel.id
    busy=true;publish();cb({Status=true})
    CreateThread(function()
        local dictionary='clothingtie'
        RequestAnimDict(dictionary)
        local expires=GetGameTimer()+1500
        while not HasAnimDictLoaded(dictionary) and GetGameTimer()<expires and not stopping do Wait(50) end
        local played=HasAnimDictLoaded(dictionary) and validPlace() and version==epoch
        if played then TaskPlayAnim(PlayerPedId(),dictionary,'try_tie_positive_a',3.0,-3.0,1200,49,0.0,false,false,false);Wait(1100) end
        if version~=epoch or stopping or not validPlace() then if version==epoch then close(state and state.Phase~='active') end;return end
        if played then StopAnimTask(PlayerPedId(),dictionary,'try_tie_positive_a',2.0) end
        TriggerEvent('fivepd:fieldops:clientRequest',json.encode({Action=choice=='restore' and 'uniform-restore' or 'uniform-equip',Preset=choice,StationId=id}),function(serialized)
            if version~=epoch or not panel then return end
            local ok,result=pcall(json.decode,serialized)
            busy=false
            if ok and type(result)=='table' and result.Status==false then publish(result.Message or '복장 변경을 승인받지 못했습니다.') else publish() end
        end)
    end)
end)
CreateThread(function()
    while not stopping do
        if panel and not validPlace() then close(state and state.Phase~='active') end
        Wait(panel and 200 or 1000)
    end
end)
AddEventHandler('onClientResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    stopping=true;close(false);restore(PlayerPedId())
end)
