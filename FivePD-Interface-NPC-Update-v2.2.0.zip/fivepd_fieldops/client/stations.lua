-- Local, streamed staff: no network entities, roaming AI or server frame loop.
FivePDStation = {}
local state, points, actors, retry = nil, {}, {}, {}
local stopping, generation, lastTalk = false, 0, 0
local roles = {
    [0]={model='s_f_y_cop_01', scenario='WORLD_HUMAN_CLIPBOARD', label='안내 담당관 · 업무 단말기', menu='Mdt'},
    [1]={model='s_m_y_cop_01', scenario='WORLD_HUMAN_GUARD_STAND', label='수감 담당관 · 현장 업무', menu='Dispatch'},
    [2]={model='s_m_y_cop_01', scenario='WORLD_HUMAN_COP_IDLES', label='장비 담당관 · 순찰 장비 지급', menu='Equipment'},
    [3]={model='s_m_m_autoshop_02', scenario='WORLD_HUMAN_CLIPBOARD', label='차량 담당관 · 출고 및 반납', menu='Vehicles'},
    [4]={model='s_f_y_cop_01', scenario='WORLD_HUMAN_CLIPBOARD', label='피복 담당관 · 근무복 변경'},
}

local function key(point)
    local p=point.Position
    return ('%s:%.3f:%.3f:%.3f'):format(point.Type,p.X,p.Y,p.Z)
end
local function remove(id)
    local actor=actors[id]
    if actor and DoesEntityExist(actor.ped) then DeleteEntity(actor.ped) end
    actors[id]=nil
end
AddEventHandler('fivepd:fieldops:localState',function(data)
    state=data
    local nextPoints={}
    for _,point in ipairs(data.AccessPoints or {}) do
        local p=point.Position
        if roles[point.Type] and p and type(p.X)=='number' and type(p.Y)=='number' and type(p.Z)=='number' then
            nextPoints[key(point)]=point
        end
    end
    for id in pairs(actors) do if not nextPoints[id] then remove(id) end end
    for id in pairs(retry) do if not nextPoints[id] then retry[id]=nil end end
    for id,actor in pairs(actors) do actor.point=nextPoints[id] end
    points=nextPoints
end)

local function create(id,point)
    local role=roles[point.Type]
    local model=GetHashKey(role.model)
    if not IsModelInCdimage(model) or not IsModelValid(model) or not IsModelAPed(model) then retry[id]=GetGameTimer()+30000;return end
    RequestModel(model)
    local untilTime,version=GetGameTimer()+2500,generation
    while not HasModelLoaded(model) and GetGameTimer()<untilTime and not stopping do Wait(50) end
    if not HasModelLoaded(model) or stopping or version~=generation or not points[id] then SetModelAsNoLongerNeeded(model);retry[id]=GetGameTimer()+30000;return end
    point=points[id]
    local p=point.Position
    if #(GetEntityCoords(PlayerPedId())-vector3(p.X,p.Y,p.Z))>70 then SetModelAsNoLongerNeeded(model);return end
    local ped=CreatePed(4,model,p.X+0.6,p.Y,p.Z-1.0,90.0,false,false)
    SetModelAsNoLongerNeeded(model)
    if not ped or ped==0 then retry[id]=GetGameTimer()+30000;return end
    SetEntityAsMissionEntity(ped,true,true)
    SetEntityInvincible(ped,true);FreezeEntityPosition(ped,true)
    SetBlockingOfNonTemporaryEvents(ped,true);SetPedCanRagdoll(ped,false)
    SetPedDropsWeaponsWhenDead(ped,false);SetPedCanBeTargetted(ped,false)
    RemoveAllPedWeapons(ped,true)
    TaskStartScenarioInPlace(ped,role.scenario,0,true)
    actors[id]={ped=ped,point=point,role=role}
end

function FivePDStation.nearest()
    if not state or state.Phase~='active' or not state.CanUseStations or state.Reviving or IsNuiFocused() then return end
    local ped=PlayerPedId()
    if IsPedInAnyVehicle(ped,false) or IsEntityDead(ped) then return end
    local own=GetEntityCoords(ped)
    local found,distance=nil,1.65
    for _,actor in pairs(actors) do
        if DoesEntityExist(actor.ped) then
            local p=actor.point.Position
            local d=#(own-vector3(p.X,p.Y,p.Z))
            if d<distance and HasEntityClearLosToEntity(ped,actor.ped,17) then found=actor;distance=d end
        end
    end
    return found
end
function FivePDStation.talk(actor)
    if not actor or GetGameTimer()-lastTalk<1200 then return end
    lastTalk=GetGameTimer()
    TaskTurnPedToFaceEntity(PlayerPedId(),actor.ped,500)
    if actor.point.Type==4 then
        TriggerEvent('fivepd:fieldops:clientRequest',json.encode({Action='wardrobe',StationId=actor.point.StationId}),function()end)
    else TriggerEvent('fivepd:fieldops:stationMenu',actor.role.menu) end
end

CreateThread(function()
    while not stopping do
        local own=GetEntityCoords(PlayerPedId())
        local count=0
        for id,actor in pairs(actors) do
            local p=actor.point.Position
            if not DoesEntityExist(actor.ped) or #(own-vector3(p.X,p.Y,p.Z))>90 then remove(id) else count=count+1 end
        end
        for id,point in pairs(points) do
            local p=point.Position
            if count<12 and not actors[id] and (retry[id] or 0)<=GetGameTimer() and #(own-vector3(p.X,p.Y,p.Z))<65 then
                create(id,point);if actors[id] then count=count+1 end
            end
        end
        Wait(1000)
    end
end)
AddEventHandler('onClientResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    stopping=true;generation=generation+1
    for id in pairs(actors) do remove(id) end
    points={};retry={}
end)
