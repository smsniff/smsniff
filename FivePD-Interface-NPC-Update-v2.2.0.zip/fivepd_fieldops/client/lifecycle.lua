-- Field lifecycle resource. Permissions, recovery deadlines and AI completion remain server authoritative.
local state, pending, requestNumber = nil, {}, 0
local appliedReviveVersion
local spawnedToken, appliedDownVersion, revivingTarget = nil, nil, nil
local lastProbe, nextPain, lastJoin, lastAck = 0, 0, 0, 0
local stationBlips, ownFocus, stopping = {}, false, false
local lastHint,lastHintKey='',''
local medicalBlur=false
local teleportBusy=false
local wardrobeBusy=false
local lastWorkspace
local resource = GetCurrentResourceName()
local firearmDisabledControls = {21,22,23,24,25,37,44,45,47,58,140,141,142,143,257,263,264}

local function request(data, callback)
    requestNumber = requestNumber + 1
    local id = ('field-%s-%s'):format(GetGameTimer(), requestNumber)
    data.RequestId = id
    if callback then pending[id] = {cb=callback, expires=GetGameTimer()+12000} end
    TriggerServerEvent('fivepd:fieldops:request', json.encode(data))
end

local function clearBlur()
    if medicalBlur then ClearTimecycleModifier();medicalBlur=false end
end

local function clearEffects()
    clearBlur()
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    SetPedSuffersCriticalHits(ped, true)
    SetPlayerInvincible(PlayerId(), false)
    if ownFocus then SetNuiFocus(false,false); ownFocus=false end
    if IsScreenFadedOut() or IsScreenFadingOut() then DoScreenFadeIn(700) end
end

local function lockUi(locked)
    TriggerEvent('fivepd:fieldops:clientLock', locked)
    if locked then
        SetNuiFocus(true,true); ownFocus=true
    elseif ownFocus then SetNuiFocus(false,false); ownFocus=false end
end

local function loadAnim(dictionary)
    RequestAnimDict(dictionary)
    local untilTime = GetGameTimer()+3500
    while not HasAnimDictLoaded(dictionary) and GetGameTimer()<untilTime and not stopping do Wait(0) end
    return HasAnimDictLoaded(dictionary)
end

local function setupStationBlips(stations)
    for _,blip in ipairs(stationBlips) do if DoesBlipExist(blip) then RemoveBlip(blip) end end
    stationBlips = {}
    for _,station in ipairs(stations or {}) do
        local p=station.MapPosition
        local blip=AddBlipForCoord(p.X,p.Y,p.Z)
        SetBlipSprite(blip,60);SetBlipDisplay(blip,4);SetBlipScale(blip,0.8)
        SetBlipColour(blip,0);SetBlipAsShortRange(blip,false)
        BeginTextCommandSetBlipName('STRING');AddTextComponentString(station.Name);EndTextCommandSetBlipName(blip)
        stationBlips[#stationBlips+1]=blip
    end
end

local function enterDown(data)
    local version=data.Version
    if appliedDownVersion==version then return end
    appliedDownVersion=version
    CreateThread(function()
        if not state or state.Phase~='downed' or state.DownedAt~=data.DownedAt then return end
        local p=data.Position
        RequestCollisionAtCoord(p.X,p.Y,p.Z)
        if IsPedInAnyVehicle(PlayerPedId(),false) then
            TaskLeaveVehicle(PlayerPedId(),GetVehiclePedIsIn(PlayerPedId(),false),4160)
            Wait(250)
        end
        if not state or state.Phase~='downed' or state.DownedAt~=data.DownedAt then return end
        NetworkResurrectLocalPlayer(p.X,p.Y,p.Z,GetEntityHeading(PlayerPedId()),true,false)
        local ped=PlayerPedId()
        SetEntityHealth(ped,175);SetPlayerInvincible(PlayerId(),false)
        SetPedSuffersCriticalHits(ped,false);ClearPedTasksImmediately(ped)
        SetTimecycleModifier('hud_def_blur');SetTimecycleModifierStrength(0.22);medicalBlur=true
        if IsScreenFadedOut() then DoScreenFadeIn(500) end
        PlayPain(ped,3,0);nextPain=GetGameTimer()+math.random(35000,55000)
        if loadAnim('combat@damage@writhe') and state and state.Phase=='downed' then
            TaskPlayAnim(ped,'combat@damage@writhe','writhe_loop',3.0,-3.0,-1,1,0.0,false,false,false)
        end
    end)
end

local function spawnAt(data)
    if spawnedToken==data.SpawnToken then return end
    spawnedToken=data.SpawnToken
    CreateThread(function()
        if not state or state.Phase~='spawning' or state.SpawnToken~=data.SpawnToken then return end
        DoScreenFadeOut(400)
        while not IsScreenFadedOut() and not stopping do Wait(0) end
        if not state or state.Phase~='spawning' or state.SpawnToken~=data.SpawnToken then return end
        local p=data.Position
        RequestCollisionAtCoord(p.X,p.Y,p.Z)
        NetworkResurrectLocalPlayer(p.X,p.Y,p.Z,data.Heading or 90.0,true,false)
        local ped=PlayerPedId()
        ClearPedTasksImmediately(ped);SetEntityCoordsNoOffset(ped,p.X,p.Y,p.Z,false,false,false)
        SetEntityHeading(ped,data.Heading or 90.0)
        SetEntityHealth(ped,GetEntityMaxHealth(ped));SetPedArmour(ped,0)
        RemoveAllPedWeapons(ped,true);ClearPedBloodDamage(ped)
        FreezeEntityPosition(ped,true);SetPlayerInvincible(PlayerId(),false)
        local untilTime=GetGameTimer()+5000
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer()<untilTime and not stopping do Wait(0) end
        FreezeEntityPosition(ped,false);clearBlur();SetPedSuffersCriticalHits(ped,true)
        DoScreenFadeIn(900)
        request({Action='spawned',Token=data.SpawnToken})
    end)
end

RegisterNetEvent('fivepd:fieldops:reply',function(id,serialized)
    local entry=pending[id]
    if not entry then return end
    pending[id]=nil
    entry.cb(serialized)
end)

RegisterNetEvent('fivepd:fieldops:waypoint',function(x,y)
    if type(x)=='number' and type(y)=='number' then SetNewWaypoint(x,y) end
end)

RegisterNetEvent('fivepd:fieldops:state',function(serialized)
    local ok,data=pcall(json.decode,serialized)
    if not ok or type(data)~='table' then return end
    if state and data.Version<state.Version then return end
    local previous=state and state.Phase
    local first=not state
    state=data
    TriggerEvent('fivepd:fieldops:localState',data)
    if first then setupStationBlips(data.Stations) end
    local locked=data.Phase~='active'
    if locked and (not previous or previous=='active') then lockUi(true) end
    if data.Directive=='down' or (data.Phase=='downed' and previous~='downed') then enterDown(data) end
    if data.Directive=='spawn' or (data.Phase=='spawning' and previous~='spawning') then spawnAt(data) end
    if data.Phase=='dead' and previous~='dead' then
        ClearPedTasksImmediately(PlayerPedId());SetEntityHealth(PlayerPedId(),0)
        DoScreenFadeOut(12000)
    end
    if data.Directive=='revived' and appliedReviveVersion~=data.Version then
        appliedReviveVersion=data.Version
        NetworkResurrectLocalPlayer(data.Position.X,data.Position.Y,data.Position.Z,GetEntityHeading(PlayerPedId()),true,false)
        SetEntityHealth(PlayerPedId(),140);ClearPedTasksImmediately(PlayerPedId())
        clearEffects();lockUi(false)
    elseif data.Phase=='active' and previous~='active' then clearEffects();lockUi(false) end
    local target=data.Reviving and data.Reviving.TargetId
    if target~=revivingTarget then
        TriggerEvent('fivepd:fieldops:clientLock', target~=nil or locked)
        revivingTarget=target
        if target then
            CreateThread(function()
                if loadAnim('mini@cpr@char_a@cpr_str') and revivingTarget==target then
                    local p=data.Reviving.Location
                    TaskTurnPedToFaceCoord(PlayerPedId(),p.X,p.Y,p.Z,500);Wait(450)
                    if revivingTarget==target and state and state.Phase=='active' then
                        TaskPlayAnim(PlayerPedId(),'mini@cpr@char_a@cpr_str','cpr_pumpchest',4.0,-4.0,-1,1,0.0,false,false,false)
                    end
                end
            end)
        else ClearPedTasks(PlayerPedId()) end
    end
    TriggerEvent('fivepd:fieldops:clientState',locked or target~=nil or teleportBusy or wardrobeBusy)
    data.Event='fivepd:fieldops:state'
    SendNUIMessage(data)
end)

-- Local IPC from the FivePD map. This is deliberately not a network event.
AddEventHandler('fivepd:fieldops:clientRequest',function(serialized,cb)
    local ok,data=pcall(json.decode,serialized)
    if not ok or type(data)~='table' then cb(json.encode({Status=false,Message='잘못된 요청입니다.'}));return end
    request(data,cb)
end)

RegisterNUICallback('fivepd:fieldops:action',function(data,cb)
    if type(data)~='table' then cb(json.encode({Status=false,Message='잘못된 요청입니다.'}));return end
    request(data,cb)
end)
RegisterNUICallback('fivepd:fieldops:ready',function(_,cb)
    if state then state.Event='fivepd:fieldops:state';SendNUIMessage(state) end
    SendNUIMessage({Event='fivepd:fieldops:hint',Text=lastHint,Key=lastHintKey})
    SendNUIMessage({Event='fivepd:fieldops:workspace',Open=lastWorkspace==true})
    TriggerEvent('fivepd:fieldops:stationReady')
    request({Action='sync'})
    cb(json.encode({Status=true}))
end)

AddEventHandler('fivepd:fieldops:workspace',function(open)
    open=open==true
    if lastWorkspace~=open then
        lastWorkspace=open
        SendNUIMessage({Event='fivepd:fieldops:workspace',Open=open})
    end
end)

AddEventHandler('fivepd:fieldops:teleportLock',function(locked)
    teleportBusy=locked==true
    TriggerEvent('fivepd:fieldops:clientLock',teleportBusy or wardrobeBusy or (state and (state.Phase~='active' or state.Reviving~=nil)) or false)
end)
AddEventHandler('fivepd:fieldops:wardrobeLock',function(locked)
    wardrobeBusy=locked==true
    TriggerEvent('fivepd:fieldops:clientLock',wardrobeBusy or teleportBusy or (state and (state.Phase~='active' or state.Reviving~=nil)) or false)
end)

-- Station badge texture: the same supplied PNG is used by the NUI map and the GTA police-station sprite.
CreateThread(function()
    RequestStreamedTextureDict('blips',false)
    local untilTime=GetGameTimer()+7000
    while not HasStreamedTextureDictLoaded('blips') and GetGameTimer()<untilTime do Wait(50) end
    local dict=CreateRuntimeTxd('fivepd_station_badge')
    local texture=CreateRuntimeTextureFromImage(dict,'mission_row','assets/mission-row.png')
    if texture then AddReplaceTexture('blips','radar_police_station','fivepd_station_badge','mission_row')
    else print('[FivePD FieldOps] Station PNG could not be registered as a GTA texture.') end
end)

local function stopAutoSpawn()
    if GetResourceState('spawnmanager')=='started' then
        pcall(function() exports.spawnmanager:setAutoSpawn(false) end)
    end
end

CreateThread(function()
    while not NetworkIsSessionStarted() or not NetworkIsPlayerActive(PlayerId()) do Wait(100) end
    while not stopping do
        stopAutoSpawn()
        if state then TriggerEvent('fivepd:fieldops:clientState',state.Phase~='active' or state.Reviving~=nil or teleportBusy or wardrobeBusy) end
        if not state and GetGameTimer()-lastJoin>2500 then lastJoin=GetGameTimer();request({Action='join'}) end
        local now=GetGameTimer()
        for id,entry in pairs(pending) do
            if now>=entry.expires then pending[id]=nil;entry.cb(json.encode({Status=false,Message='서버 응답을 기다리지 못했습니다. 다시 시도해 주세요.'})) end
        end
        Wait(500)
    end
end)

local function text3d(position,message)
    local onScreen,x,y=World3dToScreen2d(position.X,position.Y,position.Z+0.65)
    if not onScreen then return end
    SetTextScale(0.0,0.32);SetTextFont(0);SetTextCentre(true);SetTextOutline()
    BeginTextCommandDisplayText('STRING');AddTextComponentSubstringPlayerName(message);EndTextCommandDisplayText(x,y)
end

CreateThread(function()
    while not stopping do
        local waitTime=500
        local hint,hintKey='',''
        if state then
            local ped=PlayerPedId();local phase=state.Phase;local now=GetGameTimer()
            if phase~='active' then
                waitTime=0
                DisableAllControlActions(0);DisablePlayerFiring(PlayerId(),true);HideHudAndRadarThisFrame()
                if phase=='selecting' then FreezeEntityPosition(ped,true) end
                if phase=='downed' and now>=nextPain and not IsEntityDead(ped) then
                    PlayPain(ped,3,0);nextPain=now+math.random(40000,65000)
                end
                if not IsNuiFocused() then SetNuiFocus(true,true);ownFocus=true end
            elseif state.Reviving then
                waitTime=0
                DisablePlayerFiring(PlayerId(),true)
                for _,control in ipairs(firearmDisabledControls) do DisableControlAction(0,control,true) end
                if IsControlJustPressed(0,32) or IsControlJustPressed(0,33) or IsControlJustPressed(0,34) or IsControlJustPressed(0,35) or IsControlJustPressed(0,73) then
                    request({Action='cancel-revive'})
                end
            elseif state.CanRevive and not wardrobeBusy and not teleportBusy and not IsNuiFocused() then
                local own=GetEntityCoords(ped)
                for _,target in ipairs(state.Downed or {}) do
                    local p=target.Location
                    if #(own-vector3(p.X,p.Y,p.Z))<3.0 then
                        waitTime=0;text3d(p,target.Busy and '[...]' or '[E]')
                        hint=target.Busy and '다른 경관이 응급처치를 진행하고 있습니다.' or '동료 경관 응급처치'
                        hintKey=target.Busy and '' or 'E'
                        if not target.Busy and IsControlJustPressed(0,38) then request({Action='revive',TargetId=target.Id}) end
                    end
                end
            end
            if phase=='active' and not state.Reviving and not teleportBusy and not wardrobeBusy and not lastWorkspace and hint=='' and FivePDStation then
                local actor=FivePDStation.nearest()
                if actor then
                    waitTime=0;hint=actor.role.label..' · 대화하기';hintKey='E'
                    if IsControlJustPressed(0,38) then FivePDStation.talk(actor) end
                end
            end
            if phase=='active' and (IsEntityDead(ped) or GetEntityHealth(ped)<=100) and now-lastProbe>500 then
                lastProbe=now;request({Action='probe'})
            end
            if phase=='spawning' and spawnedToken and now-lastAck>1500 then
                lastAck=now;request({Action='spawned',Token=spawnedToken})
            end
        end
        if hint~=lastHint or hintKey~=lastHintKey then
            lastHint,lastHintKey=hint,hintKey
            SendNUIMessage({Event='fivepd:fieldops:hint',Text=hint,Key=hintKey})
        end
        Wait(waitTime)
    end
end)

AddEventHandler('onClientResourceStop',function(name)
    if name~=resource then return end
    stopping=true;clearEffects();ClearPedTasks(PlayerPedId());TriggerEvent('fivepd:fieldops:clientLock',false)
    RemoveReplaceTexture('blips','radar_police_station')
    for _,blip in ipairs(stationBlips) do if DoesBlipExist(blip) then RemoveBlip(blip) end end
    for _,entry in pairs(pending) do entry.cb(json.encode({Status=false,Message='리소스가 종료됐습니다.'})) end
    pcall(function() exports.spawnmanager:setAutoSpawn(true) end)
end)
