-- Native freemode clothing only: no model, face, hair, health, armor or weapon changes.
FivePDUniforms = {
    mp_m_freemode_01 = {components={
        [3]={0,0}, [4]={35,0}, [5]={0,0}, [6]={25,0}, [7]={0,0},
        [8]={58,0}, [9]={0,0}, [10]={0,0}, [11]={55,0},
    }, cap={46,0}},
    mp_f_freemode_01 = {components={
        [3]={14,0}, [4]={34,0}, [5]={0,0}, [6]={25,0}, [7]={0,0},
        [8]={35,0}, [9]={0,0}, [10]={0,0}, [11]={48,0},
    }, cap={45,0}},
}
