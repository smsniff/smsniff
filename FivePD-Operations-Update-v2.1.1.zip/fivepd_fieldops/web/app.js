import {request} from './transport.js';
import {Narrative} from './narrative.js';

const screen = document.querySelector('#screen');
const cpr = document.querySelector('#cpr');
const hint = document.querySelector('#hint');
const narrative = new Narrative();
const emsLabels = {
  queued: '구급대 배차 대기', 'finding-route': '현장 접근 도로 확인 중',
  enroute: '구급대 현장 이동 중', treating: '구급대원 응급처치 중',
  hold: '동료 경관에게 처치 인계', offline: '구급대 현장 대기 중',
  failed: '현장 접근 지연 · 동료 경관 구조 대기', retiring: '구급대 임무 완료',
};
let state, received = 0, timer, busy = false, panelPhase, deathKey;
const setText = (selector, value) => { const el = document.querySelector(selector); if (el && el.textContent !== String(value)) el.textContent = value; };
const now = () => (state?.ServerNow || 0) + (performance.now() - received) / 1000;
const remaining = () => Math.max(0, Math.ceil((state?.Phase === 'dead' ? state.RespawnAt : state?.Deadline || 0) - now()));

async function act(action, extra = {}) {
  if (busy) return;
  busy = true; refresh();
  const result = await request(action, extra);
  busy = false;
  setText('#message', result.Message || ''); refresh();
}
function buildPanel() {
  narrative.stop();
  panelPhase = state.Phase; screen.dataset.phase = panelPhase;
  screen.hidden = panelPhase === 'active'; screen.replaceChildren();
  if (panelPhase === 'active') return;
  if (panelPhase === 'selecting') {
    screen.innerHTML = '<section class="station-entry"><div class="entry-heading"><span class="eyebrow">LOS SANTOS POLICE · FIVEPD</span><h1>오늘의 근무는<br>여기서 시작됩니다.</h1><p>출근할 경찰서를 선택하세요.</p></div><div id="stations"></div><p id="message" role="status"></p><footer>순찰 장비는 경찰서 캐비닛에서 지급받을 수 있습니다.</footer></section>';
    for (const station of state.Stations || []) {
      const button = document.createElement('button'); button.className = 'station-option';
      button.innerHTML = '<img src="../assets/mission-row.png" alt="경찰서 배지"><div><small>01 / POLICE STATION</small><h2></h2><p>장비 캐비닛 · 순찰 차량 출고</p></div><span aria-hidden="true">↗</span>';
      button.querySelector('h2').textContent = station.Name;
      button.addEventListener('click', () => act('spawn', {StationId: station.Id}));
      screen.querySelector('#stations').append(button);
    }
  } else if (panelPhase === 'spawning') {
    screen.innerHTML = '<div class="loading"><span></span><p>경찰서로 이동 중</p></div>';
  } else if (panelPhase === 'downed') {
    screen.innerHTML = '<div class="vignette"></div><section class="recovery"><div class="medical-label"><span>+</span> EMERGENCY MEDICAL RESPONSE</div><h1>의식 불명</h1><p class="recovery-copy">동료 경관의 응급처치를 기다리세요.</p><div class="recovery-clock"><span>구조 가능 시간</span><strong id="remaining"></strong></div><p id="rescuer" hidden>경관이 심폐소생술을 진행하고 있습니다.</p><div id="ems" hidden><span class="ems-pulse"></span><div><strong id="ems-label"></strong><small id="ems-detail"></small></div></div><button class="emergency" id="panic"><span>+</span><strong id="panic-label">경관 긴급 구조 요청</strong><kbd>H</kbd></button><small id="panic-hint"></small><p id="message" role="status"></p></section>';
    screen.querySelector('#panic').addEventListener('click', () => act('down-panic'));
  } else if (panelPhase === 'dead') {
    screen.innerHTML = '<div class="vignette"></div><section class="memorial"><span class="memorial-rule"></span><p class="eyebrow">다시, 도시를 지킬 시간</p><p id="memorial-line"></p><div class="return-clock"><span>현장 복귀까지</span><strong id="remaining"></strong><small>초</small></div><div class="return-track"><span></span></div><p class="return-location">미션로우 경찰서에서 다시 시작합니다.</p></section>';
    deathKey = undefined;
  }
}
function refresh() {
  if (!state) return;
  if (panelPhase !== state.Phase) buildPanel();
  const seconds = remaining();
  const dead = state.Phase === 'dead';
  setText('#remaining', dead ? seconds : `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`);
  if (state.Phase === 'downed') {
    screen.classList.toggle('critical', seconds < 30);
    screen.style.setProperty('--vignette', String(Math.min(.72, .12 + Math.max(0, 30 - seconds) * .02)));
    document.querySelector('#rescuer').hidden = !state.Rescuer;
    const ems = state.Ems;
    document.querySelector('#ems').hidden = !ems;
    setText('#ems-label', emsLabels[ems?.Stage] || '구급대 위치 확인 중');
    setText('#ems-detail', ems?.Stage === 'enroute' && ems.Distance >= 0 ? `현재 거리 ${ems.Distance}m` : '현장의 안전과 접근 상황에 따라 도착이 지연될 수 있습니다.');
    const panic = document.querySelector('#panic');
    panic.disabled = !state.CanPanic || state.PanicSent || busy;
    setText('#panic-label', state.PanicSent ? '긴급 구조 요청 전송됨' : '경관 긴급 구조 요청');
    setText('#panic-hint', state.CanPanic ? '근무 중인 경관에게 현재 위치가 전달됩니다.' : '동료 경관이 가까이에서 응급처치를 시작할 수 있습니다.');
  }
  if (dead) {
    document.querySelector('.return-track span').style.width = `${100 * seconds / (state.RespawnDelay || 15)}%`;
    const key = `${state.DownedAt}:${state.RespawnAt}`;
    if (deathKey !== key) {
      deathKey = key;
      void narrative.start(document.querySelector('#memorial-line'), state.DeathLine || '당신이 지킨 순간들은 이 도시에 남아 있습니다.', state.AudioVolume ?? .5);
    }
  }
  if (state.Phase === 'selecting') for (const button of screen.querySelectorAll('button')) button.disabled = busy;
  cpr.hidden = state.Phase !== 'active' || !state.Reviving;
  if (!cpr.hidden) {
    const progress = Math.max(0, Math.min(100, (1 - (state.Reviving.CompletesAt - now()) / (state.ReviveDuration || 10)) * 100));
    cpr.querySelector('progress').value = progress;
    setText('#cpr-percent', `${Math.floor(progress)}%`);
  }
  hint.hidden = state.Phase !== 'active' || !!state.Reviving || !hint.querySelector('span').textContent;
}
function updateClock() {
  const needsClock = state && (['downed', 'dead'].includes(state.Phase) || state.Reviving);
  if (needsClock && !timer) timer = setInterval(refresh, 200);
  if (!needsClock && timer) { clearInterval(timer); timer = undefined; }
}
window.addEventListener('message', ({data}) => {
  if (!data || typeof data !== 'object') return;
  if (data.Event === 'fivepd:fieldops:state') {
    if (!['selecting','spawning','active','downed','dead'].includes(data.Phase)) return;
    if (state && data.Version < state.Version) return;
    state = data; received = performance.now(); refresh(); updateClock();
  } else if (data.Event === 'fivepd:fieldops:hint') {
    hint.querySelector('kbd').textContent = data.Key || '';
    hint.querySelector('kbd').hidden = !data.Key;
    hint.querySelector('span').textContent = data.Text || '';
    if (state) refresh();
  } else if (data.Event === 'fivepd:fieldops:workspace') {
    hint.classList.toggle('workspace-open', !!data.Open);
  }
});
window.addEventListener('keydown', event => {
  if (state?.Phase === 'downed' && event.code === 'KeyH' && !event.repeat && state.CanPanic && !state.PanicSent) {
    event.preventDefault(); void act('down-panic');
  }
  if (state && state.Phase !== 'active' && ['Escape','Enter','KeyB','F4','F6','F10','F11'].includes(event.code)) event.preventDefault();
});
window.addEventListener('pagehide', () => { clearInterval(timer); narrative.stop(); });
void request('sync', {}, 'fivepd:fieldops:ready');
