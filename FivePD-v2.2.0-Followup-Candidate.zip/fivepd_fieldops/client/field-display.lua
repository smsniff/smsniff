-- Display only: names stay in the current GTA language; no saved data is changed.
local active,workspace,stopping=false,false,false
AddEventHandler('fivepd:fieldops:localState',function(s) active=s.Phase=='active' end)
AddEventHandler('fivepd:fieldops:workspace',function(open) workspace=open==true end)
local function label(code)
    if not code or code=='' then return '' end
    local value=GetLabelText(code)
    return value~='NULL' and value or code
end
CreateThread(function()
    while not stopping do
        local visible=active and not workspace and not IsNuiFocused() and not IsPauseMenuActive()
        local vehicle,location='', ''
        if visible then
            local ped=PlayerPedId()
            local p=GetEntityCoords(ped)
            local street,cross=GetStreetNameAtCoord(p.x,p.y,p.z)
            local road=GetStreetNameFromHashKey(street)
            local zone=label(GetNameOfZone(p.x,p.y,p.z))
            location=road~='' and (road..' · '..zone) or zone
            if IsPedInAnyVehicle(ped,false) then
                vehicle=label(GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(ped,false))))
            end
        end
        SendNUIMessage({Event='fivepd:field:display',Visible=visible,Vehicle=vehicle,Location=location,Labels=visible and FivePDStation.labels() or {}})
        Wait(100)
    end
end)
CreateThread(function()
    while not stopping do
        if active and not workspace and not IsNuiFocused() and not IsPauseMenuActive() then
            HideHudComponentThisFrame(6);HideHudComponentThisFrame(7);HideHudComponentThisFrame(9)
            Wait(0)
        else Wait(100) end
    end
end)
AddEventHandler('onClientResourceStop',function(name)
    if name==GetCurrentResourceName() then stopping=true end
end)
