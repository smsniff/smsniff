-- Display only: regions are Korean; vehicle labels keep the current GTA language.
local active,workspace,stopping=false,false,false
local nativeVehicle,nativeLocation='',''
AddEventHandler('fivepd:fieldops:localState',function(s) active=s.Phase=='active' end)
AddEventHandler('fivepd:fieldops:workspace',function(open) workspace=open==true end)
local function label(code)
    if not code or code=='' then return '' end
    local value=GetLabelText(code)
    return value~='NULL' and value or code
end
-- Native cursive is the GTA script style in the supplied examples. Never send
-- Korean/CJK to this font: those strings keep the bundled NUI glyph fallback.
local function cursiveSupported(text)
    for _,code in utf8.codes(text) do
        if code>0x024F then return false end
    end
    return true
end
local function addText(text)
    local chunk=''
    for _,code in utf8.codes(text) do
        local ch=utf8.char(code)
        if #chunk+#ch>90 then AddTextComponentSubstringPlayerName(chunk);chunk='' end
        chunk=chunk..ch
    end
    if chunk~='' then AddTextComponentSubstringPlayerName(chunk) end
end
local function drawCursive(text,y)
    if text=='' then return end
    SetTextFont(1);SetTextProportional(true);SetTextScale(0.0,0.5)
    BeginTextCommandGetWidth('STRING');addText(text)
    local width=EndTextCommandGetWidth(true)
    local scale=width>0.66 and 0.5*0.66/width or 0.5
    SetTextFont(1);SetTextProportional(true);SetTextScale(0.0,scale)
    SetTextColour(255,255,255,255);SetTextDropshadow(2,0,0,0,220)
    SetTextOutline();SetTextCentre(false);SetTextRightJustify(true);SetTextWrap(0.03,0.97)
    BeginTextCommandDisplayText('STRING');addText(text);EndTextCommandDisplayText(0.97,y)
    SetTextRightJustify(false);SetTextWrap(0.0,1.0)
end
CreateThread(function()
    while not stopping do
        local visible=active and not workspace and not IsNuiFocused() and not IsPauseMenuActive()
        local vehicle,location='', ''
        if visible then
            local ped=PlayerPedId()
            local p=GetEntityCoords(ped)
            local street,cross=GetStreetNameAtCoord(p.x,p.y,p.z)
            local road=GetStreetNameFromHashKey(street)
            local zoneCode=GetNameOfZone(p.x,p.y,p.z)
            location=FivePDKoreanLocation.format(zoneCode,road,label(zoneCode))
            if IsPedInAnyVehicle(ped,false) then
                vehicle=label(GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(ped,false))))
            end
        end
        nativeVehicle=visible and cursiveSupported(vehicle) and vehicle or ''
        nativeLocation='' -- Korean region captions always use the bundled Korean script font.
        if nativeVehicle~='' then vehicle='' end
        if nativeLocation~='' then location='' end
        SendNUIMessage({Event='fivepd:field:display',Visible=visible,Vehicle=vehicle,Location=location,Labels=visible and FivePDStation.labels() or {}})
        Wait(100)
    end
end)
CreateThread(function()
    while not stopping do
        if active and not workspace and not IsNuiFocused() and not IsPauseMenuActive() then
            HideHudComponentThisFrame(6);HideHudComponentThisFrame(7);HideHudComponentThisFrame(9)
            drawCursive(nativeVehicle,0.84);drawCursive(nativeLocation,0.89)
            Wait(0)
        else Wait(100) end
    end
end)
AddEventHandler('onClientResourceStop',function(name)
    if name==GetCurrentResourceName() then stopping=true end
end)
