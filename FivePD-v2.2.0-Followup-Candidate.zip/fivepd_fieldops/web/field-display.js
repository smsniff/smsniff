const labels=document.querySelector('#staff-labels');
const caption=document.querySelector('#world-caption');
const vehicle=document.querySelector('#world-vehicle');
const location=document.querySelector('#world-location');
window.addEventListener('message',({data})=>{
  if(data?.Event!=='fivepd:field:display') return;
  caption.hidden=!data.Visible;
  vehicle.textContent=data.Vehicle||'';
  location.textContent=data.Location||'';
  const fragment=document.createDocumentFragment();
  for(const item of (data.Labels||[]).slice(0,12)) {
    if(!Number.isFinite(item.X)||!Number.isFinite(item.Y)) continue;
    const node=document.createElement('div');node.className='staff-name';
    node.style.left=`${item.X*100}%`;node.style.top=`${item.Y*100}%`;
    const name=document.createElement('strong');name.textContent=item.Name;
    const role=document.createElement('small');role.textContent=item.Role;
    node.append(name,role);fragment.append(node);
  }
  labels.replaceChildren(fragment);
});
