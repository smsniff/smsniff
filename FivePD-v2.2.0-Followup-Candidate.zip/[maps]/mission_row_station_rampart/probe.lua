-- Read-only local investigation of the floor under a player or vehicle.
RegisterCommand('missionrow_probe',function()
    CreateThread(function()
        local ped=PlayerPedId()
        local entity=IsPedInAnyVehicle(ped,false) and GetVehiclePedIsIn(ped,false) or ped
        local pos=GetEntityCoords(entity)
        local handle=StartShapeTestRay(pos.x,pos.y,pos.z+1,pos.x,pos.y,pos.z-6,17,entity,7)
        local deadline=GetGameTimer()+2000
        while GetGameTimer()<deadline do
            local status,hit,floor=GetShapeTestResult(handle)
            if status==2 then
                print(('[Rampart probe] xyz=%.3f,%.3f,%.3f interior=%s collision=%s floorHit=%s floorZ=%.3f'):format(pos.x,pos.y,pos.z,GetInteriorFromEntity(entity),tostring(HasCollisionLoadedAroundEntity(entity)),tostring((hit==true or hit==1)),floor.z))
                return
            end
            Wait(25)
        end
        print('[Rampart probe] collision trace timed out')
    end)
end,false)
