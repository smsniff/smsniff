fx_version 'cerulean'
game 'gta5'
version '1.0.2'

this_is_a_map 'yes'

files {'stream/*.ytyp'}
data_file 'DLC_ITYP_REQUEST' 'stream/downtown_01_metadata_002_strm.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/hei_dlc_heist_police.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/mrs_garage.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/mrs_interior.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/mrs_objects.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/mrs_props.ytyp'

server_script 'status.lua'
rampart_compat '1.0.1'

client_script 'probe.lua'
