fx_version 'cerulean'
game 'gta5'

author 'smsniff'
description 'Standalone reference-style weapon wheel for FivePD'
version '1.1.1'

ui_page 'web/index.html'
client_scripts { 'config.lua', 'weapons.lua', 'client.lua', 'status_client.lua' }
server_scripts { 'config.lua', 'server.lua' }
files { 'web/index.html', 'web/style.css', 'web/model.mjs', 'web/icons.mjs', 'web/catalog.mjs', 'web/audio.mjs', 'web/app.mjs', 'web/fonts/*', 'web/images/*', 'web/sounds/*' }
